<?php
// en la carpeta de public tenemos todo lo que nos representa peligro
/*
    Tenemos el acceso que el cliente puede hacer
    app esta lalogica del negocio, debe estar protegida y no se debe ver
    solo se accesa en la aplicacion (htaccess)

    las configuraciones las hacemos htaccess(hacer configuaciones en cada cliente)
    Aquui van las carpetas: 
        libraries - es como la carpeta de clases en el otro poryecto
        files - para la perte de exportacion (json,csv)
        helpers - para poner varias funciones, optener la fecha actual, cosas auxiliares
        libraries - van las clases principales
        public - es el inicio el que nos da la puerta a la parte privada
        model, views, controlller - MODELO(base de datos) Vista (ptresentacion) y Controlador(logica de negocio)


    Para inciar vamos a hacer un sistema de logeo, vamos a usar tablas de base de datos    
        xampp - localhost/phpmyadmin/
            creacion de BD: pw20213m (Hacer diccionario de datos, no queremos niguno en nulo)
            creacion de tablas:
                usuarios:
                    usuario_id - INT,(registro de control) autoincrement, primarykey
                    usuario_uid - (tinytext)==varchar 255
                    usuario_nombre - tinytext
                    usuario_password - tinytext
                    usuario_email - tinytext
    */
# Aqui vamos a trabajar con la Carga del Iniciador de la apicacion
// estamos en public, vamos a app, carga el archivo de configuracion y las librerias
include_once '../app/includes/autoload.inc.php';
# Iniciamos el proceso de valoracion de rutas
$iniciar = new Ruta;
/* requerimos de diferentes situaciones de seguiridad, en la carpeta app, debe inciarse la situacion de control para la seguridad.tenemos tres archivos de apoyo
pra la parte de seguiridad, en la carpeta incial, se tiene que llamar .htaccess */