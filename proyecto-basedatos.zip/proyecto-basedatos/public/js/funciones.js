// Aqui Ejemplo de JQuery
$(function(){
    //document.querySelector('$saludo').addEventListener('click',function(){});
    //Asi era como antes con JS

    /*En Jquery
    $('#saludo').click(function(){});
    
    SE le pueden asociar mas eventos
    $('#saludo').dbclick(function(){});
    Para mejor se usa dos eventos en una misa funcion
    $('#saludo').on('click dbclick',function(){});*/

    //Vamos a usar esta para un solo evento, Para buscar en el arbol de nodos solo con $() funcin JQuery y dentro un selector, despues el metodo on(Se Le Pasan los Eventos, se le pone una funcion)
    $('#saludo').on('click',function(){
        // Cambiar un atributo de CSS con una clase y con el StyleSheet de Bootstrap por eso le posimos ese nombre de clase
        $('#mensaje').attr('class','text-success');
        //Queremos al idmensaje en el innerHTML se le asigne un saludo
        $('#mensaje').html=("HOLA -------- PUT@");
        // innerHTML == html();
        // innerText == text();
        /*
            Parte de JQuery con Ajax y Validacion (Como datos no entre basura), del lado del cliente (como Expreciones regular) y del lado servidor
        */
    });


    // Boton Leer
    $('#leer').on('click',function(){
        //Vamos a leer el archivo txt y ponerlo en la pagina
        /*Metodo Ajax (Nececita un objeto de JSON que estan delimitado por {}
        ), Aqui iniciamos XMLHTTPRequest*/
        
        /* Ajax Sucess y Erro
        $.ajax({
            Nececitabamos antes un 
            Metodo,URL ------ Open
            Datos ----------- Send
            Respuesta ----    responseText, responseXML
            RedyState,Status ----- onReadyStateChange

            Los vamos a trabajar por un metodo
            succeess(4,200) --- done, (Se usa uno de los dos)
            error(4,501) -----  fail (En casode que ocurra un erroe)
            
           /////////////////////////////////////////////////////////////////////////////////////////////////////////////
           // Segun el Objeto JSON Este podria estar como cadena lo que es 'url' y 'type', se pueden omitir, ya sabe el metodo que va esta estructura
           url:'../archivos/lectura.txt',
           type:'GET', //method
           dataType: 'text',//Decirle como vamos a recibir eso datos  response, como vamos a recibir texto por eso es text
           success: function(sLectura){
               //Si todo esta OK, buscamos el nodo por su ID y como es texto usamos text
               $('#lectura').text(sLectura);
           },// Esto es como ReadyState=4, status = 200, Segun nuestro primer ejemplo de Ajax, cuando suscede el 4 y 200 le asignamos valor a una variable, le pusimos sLectura
           error: function(evt){
               //USAMOS error solo para debug, ya cuando veamos que funciones esto se quita porque le da al usuario informacion del servidor
               //Le pusimos esa variable como parametro 'evt'. usamos la propiedad responseText();
                console.log(evt.responseText);
           },// ReadyState=4 o != 4 status != 200
           
           // Si no queremos poner el error y dejar que fuera algo controlado
           //Aqui seestaria capturando el Error y asi ya no sale en el debug informacion que no tiene porque ver el cliente
           statusCode:{
                //Mandamos un argumento segun nos regrese el HTTP coon su codigo error, se puede asociar a una funcion
                404:function(){
                    $('#lectura').text('El recurso no se encuentra');
                },
                //Si tubieramos un error de un metodo no implemetado, en lugar de GET pusieramos otra coas, nos regresa un 501
                501:function(){
                    $('#lectura').text('Metodo no soportado');
                },
           }
        });*/
        // Ajax con DONE y Fail        
        $.ajax({// Aqui es como poner $.ajax({}).done(function(){}).fail(function(){});, esto esta simplificado abaja con DONE()
           // Si no queremos poner el error y dejar que fuera algo controlado
           //Aqui seestaria capturando el Error y asi ya no sale en el debug informacion que no tiene porque ver el cliente
           statusCode:{
                //Mandamos un argumento segun nos regrese el HTTP coon su codigo error, se puede asociar a una funcion
                404:function(){
                    $('#lectura').text('El recurso no se encuentra');
                },
                //Si tubieramos un error de un metodo no implemetado, en lugar de GET pusieramos otra coas, nos regresa un 501
                501:function(){
                    $('#lectura').text('Metodo no soportado');
                },
            },
           // Segun el Objeto JSON Este podria estar como cadena lo que es 'url' y 'type', se pueden omitir, ya sabe el metodo que va esta estructura
           url:'../archivos/lectura.txt',
           type:'GET', //method
           dataType: 'text',//Decirle como vamos a recibir eso datos  response, como vamos a recibir texto por eso es text
           
           
        })
        .done(function(sLectura){
            $('#lectura').text(sLectura)})
        .fail( function(evt){
            // console.log(evt.responseText);
        });// fin de fail, Iniciamos con XML HttpRequest
    });



});// saber que ya esta cargada la pagina

