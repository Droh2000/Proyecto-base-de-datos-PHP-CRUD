/*
    Funcion validar()

    entrada: ninguna
    salida: boolean
*/
function validar(){
    // Cumplimineto del diccionario de datos
    //Podemos validar el nombre no este vacio, longitudd, texto
    /* Nos interesa el Value que esta en el input del HTML que forma parte del arbol de nodo, lo podemos buscar por nombre,id o por la etiqueta
        Usando la funcion getElement -- que nos regresa un arreglo segun donde se encunetre el atributo para buscarlo
    
        El nodo esta identificado con el nombre en input(del FORM) es parte del arbol de nodo, lo vamos a buscar por la id
        para ir al nodo raiz, si fuera con terminacion 's' como getElementsById, nos retorna un arreglo
     */
    var nombre=document.getElementById('nombre').value;/* Le pusimos .value para sacar el valor que se escriba del form */
    
    // Para ver que nos regresa en debug
    console.log(nombre);

    /*
        Vamos a enviar  un nombre solo cuando sea true
        Detetamos los posiblees errores
        en el tercero usamos expresiones regulares: /ExpresionRegular/.test(NombreVariable), queremos probar si son puros espacios
        usando: / / sustituyendo las comillas, desdeel inciohasta el final busca uno o mas espacios, si se cumple
        reglresa espacios

        !isNaN(nombre) -- paraque nos detecte si es un numero, asi con la negacion para que solosea texto

    */
   if(nombre==null || nombre=='' || !isNaN(nombre) || /^\s+$/.test(nombre)){
        alert("El nombre no esta correcto");// Este para mandar unmensaje
        // Poner el Focus
        document.getElementById('nombre').select();// con select lo selecciona el texto y lo podemos vorrar
        return false;
   }
   return true;
   
}
/*
Funcion saludar: 
    entrada: nombre,default
    salida: cadena
*/
// Los valores default
function saludar(nombre='Sin definir'){
    // Que nos retorn en la parte de saludar, se refleje el saludo
    // el innerHTML(nos asepta en la cadena otras etiquetas html) y el innerText (solo texto), pero en si imrpimen lo mismo
    document.getElementById("saludo").innerHTML="Hola "+nombre;
    
}

/* Area General para crear Tabla
Contenido de asignacion de Evento a Elemntos
uso de funiones anonimas

1. Asociar eventos a elementos (button)
2. Asociarle una funcion a ese evento
*/
// del arbol de nodo como tenemos un id, usamos ese, le asociamos in evento valido para el boton
// y a este evento hay que asociarle una funcion, anonima que esta no tienen nombre
document.getElementById('crearTabla').addEventListener('click',function(){
    //Vamos a trabajar con el cuerpo de la tabla

    //creamos la variables con la cantidad de col o ren
    var nRen=5;
    var nCol=5;
    // usaremos metodo pra crear nodos
    var cuerpoTabla = document.getElementById('contenidoTabla');
    // Para que no se puedan agregar varios, esto lo elimina y solo pone una
    cuerpoTabla.innerHTML='';  
    // creamos con estemtodo y dento de las 'la etiqueta html'
    var tabla=document.createElement('table');
    var tbody=document.createElement('tbody');
    //Le ponemos atributos
    tabla.setAttribute('class','table table-bordered');
    //Crear los renglones y las celdas (tr, td)
    //con el ciclo for, una combinacion de dos ya que sera como una matriz
    for(var i=0;i<nRen;i++){// Filas
        var fila=document.createElement('tr');
        for(var j=0;j<nCol;j++){ // Columnas
            var columna=document.createElement('td');
            // queremos que la columna tenga un contenido
            var textoColumna = document.createTextNode((i+1)+','+(j+1));
            //Asociamos el texto a la columna y columna a fila
            columna.appendChild(textoColumna);
            fila.appendChild(columna);
        }
        //Saliendo del ciclo de columna, vamos a asociar la fila a tbody
        tbody.appendChild(fila);
    }
    //saliendo de aqui tenemos que asociar a la table 
    tabla.appendChild(tbody);
    //Ultimo asociar la tabla con el contenedor
    cuerpoTabla.appendChild(tabla);
});

/*
                Hasta ahora vimos
    Javascrip
        Cadena
        DOM, Eventos
                    Falta por Ver
        Numeros
        Objetos
        Arreglos
*/