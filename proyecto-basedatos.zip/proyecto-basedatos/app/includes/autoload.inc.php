<?php
/*
    Si requerimos de algunos datos, Aseguramos que se esten cargando las librerias
    y los archivos de apoyo, ya que requiere que se cargen uns datos de apoyo
*/
include_once 'config.inc.php';// estamos en la misa carpeta include
// Estamos en la parte interna nececitamos usar APPROOT y no los .. para que no de error
include_once APPROOT.'/helpers/helpers.php';

/* Cargar el DoomPDF, Incluyemdo la libreria esta tiene su propia metodo de abajo */
include_once APPROOT.'/vendor/dompdf/autoload.inc.php';

/* Cargar la libreria nusoap, Nos permite generar ese lenguaje que no describe la forma de usar un servicio con SOAP */
include_once APPROOT.'/vendor/nusoap/src/nusoap.php';

# Necitamos cargar las librerias (Carga los eementos necesarios para uasar una libreria)
spl_autoload_register(function($className){
    // Aqui igual para que no de error APPROOT.
    include_once APPROOT.'/libraries/'.$className.'.php';
});// tenemos que mandar a llamar este archivo en el arranque (el archivo que esta en publi)