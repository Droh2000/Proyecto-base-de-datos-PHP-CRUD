<?php
/* aqui vamos a definir y darles el valor a cada uno*/
define('DBMOTOR','mysql');
define('DBSERVER','localhost');// aqui podemos poner la IP o el nombre de domino doende esta el servidor
define('DBNAME','pw20213m');// nombre de la base de datos
define('DBUSUARIO','root');// el usuario para ingresar a la bd
define('DBPASSWORD','');// no tenemos contraeña lo dejamos vaccio
// entonce si cambiamos motoro de BD solo CAambiariamos estas lineas
// pero es mas confiable usar un archivo de ambiente (environment)

/* APPROOT -- Parte Privada*/
/* Aqui se utilizan las constantes magicas, este donde este nos regresa la URL hasta donde esta
    (Nos regresa el directorio Interno)*/
define('APPROOT',dirname(dirname(__FILE__)));
/* URLROOT -- Parte Publica */
/* Aqui si se modifica el valor de la parte que se defina como DNS */
define('URLROOT','http://pw20213m.mx');
/* Se pueden definir otras constantes

El nombre del sistema*/
define('TITLE','Programacion WEB');

/* Pero Nececitmaos crear eso de arriba:
    Nos vamos a XAMPP - localhost://
     How-To-Guide
     Configure Virtual Host
     Ahi nos dice las instrucciones
     Nos Vamos a la carpeta del proycto xampp,apache,conf,extra
     Apribos httpd-vhost
     Copia y pega el codigo <VirtualHost>
     Cabiamos la ruta de arriba al ProyectoBaseDatos/Public
     ServerName ponemos: pw20213m.mx (Nombre de dominio)
     
*/