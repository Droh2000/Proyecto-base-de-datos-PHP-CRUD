<?php
echo 'INGRESO A Base.PHP';
/*
    Uso de la base de datos:
que la clase se llame igual que el archivo, estamos usando el MVC
lo demas es la parte de respaldo (las otras carpetas), herramientas para una presentacion estetica y validacion de datos
*/
class Base{
    /*
        tenemos varias funciones como mysql,oracle,sqlserver
        Funciones Externas (Librerias):
            ADODb: es un apoyo al mantenimiento y deciciones que se pueden dar en un futuro
        (Esta es una Libreria), PDO: es un objeto para el trabajo de conexion de base de datos (phpDataObject)
        por eso se usan librerias externas para hacer cambios en una linea (cambiamos msql a postgre), con funciones inter contruidas se tendria que hacer cambios en todo el codigo
        
    queremos que la conexion se de demanera automatica al crear la instancia
        lo hacemos en el constuctor    
    */
    private $stmt;// requerimos de una variavle privada que va a estar referida  en las consultas, con statement
    private $dbh;//handler para la parte del uso de los insert,select
    private $error;//paraelmanejo de errores

    /* 
    (Estamos construyendo el acceso a la BD)
        que psaria si: private $motor = 'mysql'; aqui esta dentro de la clase
        lo que queremos es evitar hacer modificiones, lo que se debe hacer es trabajar con un archivo de configuracion
        y ese archivo tenga una estructura de modificacion, que son de ambiente
        son archivos de texto para hacer esas configuraciones (ponemos el motor de la BD
    */
    private $motor = DBMOTOR;
    private $server = DBSERVER;
    private $basedatos = DBNAME;
    private $usuario = DBUSUARIO;
    private $password = DBPASSWORD;
    /* vamos agenerea estos valores,en la parte de include, con el archivo config.inc.php */
    /* Conexion, Crear, Leer, Actualizat, Eliminar (CRUD)
        Estamos en la parte de la caonexion con el objeto $dsn (requerimos elmotor de BD, Ubicacion,usuario,password,opciones)
        las opciones se puden poner aparte o en la parte conjunta del manejador (Consisten en un arreglo)
    */
    public function __construct(){
        /*  manejamos los errores
        
        es la varaible que va inciar la conexion (otros usan $conn)
        DEFINIDA LA dsn:
            mysql:/host=local;nombreBD
            requerimos de un motor y luego le concatenamos el host=la parte del server;Nombre de la base de datos
        */
        $dsn = $this -> motor.':host='.$this->server.';dbname='.$this->basedatos;
        /* Las opciones consisten en un arreglo, se requiere un identificador en este caso vamos a usar aosciativos y ya hay constantes predefinidas
            una de ellas es que la conexion se mantenga (no este conectando,desconectando) y el tratamiento de errores 
            Constantes ya creadas: Metodos estaticos con doble (::), del objeto PDO, traemos la constant estaticaen ese objeto
            y lo vamos asociar (=>) le decimos que se mantenga (true)
            El tratamiento de errores: usamos la propiedad estatica ATTR_ERRORMODE y lo juntamos para que lo maneje con el catch  usamos otra variable (ERRORMODE_EXCEPTION)*/
        $opciones = [PDO::ATTR_PERSISTENT=>true,PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION];
        try {
            /*manejador de BD, creamos una instancia, por parametros, nececitamos una cadena de conexion
                cadena de conexion, usaurio y password y algo opcional al conectarnos

            */
            echo 'Ingreso dentro del try en Base.php';
            $this -> dbh = new PDO($dsn, $this -> usuario, $this -> password, $opciones);
        } catch (PDOException $e) {//manejamos la parte de capturar errores
            /* El manejo de errores, nos saldra cuando no se de la conexion yq euremos que se muestre el error
             */
            $this->error='Error: '.$e->getMessage();
            echo $this->error;// Algunos usan la funcion die(), que haga un echo y que se salga
        }    

    }
    # ACCIONES CRUD
    /* Vamos hacer los metodos de escritura y lectura de la tabla de las bases de datos, usaremos el SQL 
        SQL:
            (Select campos FROM tabla WHERE Condicion (AND/OR) Condicion )
            INSERT INTO tabla (Campos) VALUES (valores)
            DELETE FROM tabla WHERE condicion
            UPDATE tabla SET campo = valor,...,WHERE condicion
       Pero al trabarr con datos (SEGURIDAD): 
        cuidarse de la inyeccion de codigo (PDO nos da las ejecuciones con una preparacion)
    */
    // HABILITAR LAS CONSULTAS(querys)
    /* controlador [en la vista capturamos los datos y el controlador los va a dirigir] */
    public function query($sql){// Este sera que tipo de consulta sera, recibe una cadena sql
        /* Preparar lo que recibe para que no genere problemas de seguridad

        premaramos a consulta con el dbh, va a prepara la consulta con el metodo: prepare() es una sentencia de ejecucion que retorna una setencia preparada que es algo validado que no tiene errores
        aseguruarnos que de verdad reciba lo que esperamos, no otra cosa modificada por un atacante,
        Por eso se usa el '?' en la consultas, asegurar que reciba lo que esperamos que reciba (int,boolean) en la consulta, lo comun es trabajr con una sintaxis especifica si usamos una variable que tiene el valor
        */
        $this->stmt=$this->dbh->prepare($sql);// prepared nos prepara el tipo de la consulta
    }

    //preapracion de la vinculacion (bind), cada una de las variable que bienen en la consulta y verificamos que si sean lo que estamos buscando segun el tipo de dato
    public function bind($parametro,$valor,$tipo=null){// nececitamos el parametro (varaible), el valor(si nececitamos recibir un tipo de dato para comprobar)
        // en caso que no le enviemos el valor, le asignaremos
        switch (is_null($tipo)) {
            case is_int($valor):// en caso que sea entero
                // le asignamos el tipo entero, tratamos la varaible como un parametro int
                $tipo=PDO::PARAM_INT;
                break;
            case is_bool($valor):
                $tipo=PDO::PARAM_BOOL;
                break;
            case is_null($valor):// si su valro es nulo
                $tipo=PDO::PARAM_NULL;
                break; 
            default:// por defecto sera de tipo cadena
            $tipo=PDO::PARAM_STR;
                break;
        }
        // Anterirmete hicimos la valoracion
        //Ahora vamos hacer el regreso del parametro validado
        /* cuando hicimos la asignacion de stnt este tiene un objeto de bindValue (le tenemos que pasar los parametros del metoo) */
        $this->stmt->bindValue($parametro,$valor,$tipo);
    }
    # METODOS DE LECTURA y Escritura === Ejecucion de la consulta
    //La parte del retorno de datos
    public function execute(){//por default el metodo que existe en el stement es el execute por eso ese nombre
        // este execute() es el que viene por defecto en el lenguaje
        $this->stmt->execute();
        // Al ejecutar la consulta, no da tres valores: UPDATE o Delete (nos regresa un boolean), SELECT puede darnos (un unico registro) o (multiples)
        // lo anteriro es lo que vamos a validar
    }
    //El regreso sea un unico registro
    public function unico(){
        //Primero hacemos la ejecucion, para eso ya tenemos el metodo execute()
        $this->execute();
        //y que de lo enteriro nos regrese, con este metodo interconstruido asociado a PDO
        return $this->stmt->fetch(PDO::FETCH_OBJ);// el regreso puede ser un arreglo normal o asociado o formato objeto, de preferncia que nos lo regrese de tipo objeto (PDO::FETCH_OBJ), nos regresa un formato de tipo JSOn
    }
    
    // el regreso sea un arreglo (multiples registro)
    public function multiple(){
        //Primero hacemos la ejecucion, para eso ya tenemos el metodo execute()
        $this->execute();
        //Aqui solo le agregamos el all
        return $this->stmt->fetchAll(PDO::FETCH_OBJ);
    }
    // Apoyo -- aveses hacemos una consulta que no nos regresa valores, es como una arreglo vacio
    public function conteoReg(){// verificar si biene algo vacio
        return $this->stmt->rowCount();// estos son metodos que ya estan escritos en PDO
    }
    //(INYECCION SQL)/////////////////// EXAMEN(investigar)////////////////////
    /*
        El acceso ideal para la seguridad:
            tenemos un borwser en la URL se pone una direccion de consulta, esta tienen que pasar por el proceso de ruteo
            estennos llama a un controlador y este a una vista que es una ventana de browser
            ////////////////////////////////////////////

        Vamos a trabajar con la clase de Routing
        (ya tenemos el Model), despues ahremos el controlador y la vista

        Para hacer esto mas a la seguridad, se trabaja con:
         URL amigable: son direciciones de paginas mas faciles de escribir,recordar y google interpreta con mayor relevancia
         lo que tenemos el: (Quitamos esto: recurso (separador)? Datos variable y su valor), Se envian los puros valores, tenemos mas seguridad porque no enviamos variables
    
         Esto es en alrchivo: Ruta.php en libraries
    */



}// fin de la clase