<?php
/* */
# Adminisrador de controladores,es una manera de acelerar,para no andar escribiendo en cada controlador

class Controller{
    // si nececitamos que algo se ejecute automaticamente
    public function __construct(){
        // TODO...cuestiones de sugiroda
    }
    /* el controlador llama a los modelos y a las vistas */
    # llamar a las vistas
    public function view($view, $data=[]){// qe reciba la vista y el despliege del html (que requiere de datos) pero si no, le ponemos un arreglo vacio
        //le enviamos $data para que despliege los datos
        // Tenemos que cargar la vista, en sudeterminado paquete y con extencion php porque si no lo carga
        /* Hay que remplazar todos los ../ por APPROOT. */
        if(file_exists(APPROOT.'/views/'.$view.'.php')){
            //usamos la seguridad
            include_once APPROOT.'/views/'.$view.'.php';
        }else{
            //si la vista no existe, mostramos un mensaje y salimos
            die('La vista no existe');
        }
    }// usamos este metodo cuando construyamos los controladores
    
    # llamar a los controladores
    public function model($model){// aqui recibimos un modelo
        //Podriamos validar si existe el archivo, etc.....
        include_once APPROOT.'/models/'.$model.'.php';
        return new $model();// la vista no la retornamos porque se carga pero el modelo es usado para generar una instancia por tato lo retornamos
    }
}