<?php
/* Estamos trbajando con la parte de las rutas y URL amigable (Otra cosa de estas es que no tienen la extencion .php) */
# Mapear las url
/* Vamos hacer de esto muty personalida, con tres elemntos,
    controlador.Metodo, Argumentos
*/
class Ruta{
    // Esto es la parte del controlador default, para ponerlo el de incio, se le pone Home
    protected $controladorActual = 'Home';// esto queire decir que tdebemos tener en la carpeta Controller que tenga ese nombre 'Home'
    // nececitamos un metodo que es el default para todo incio de una pagina
    protected $metodoActual = 'index';
    // nececitamos argumentos (Parametros),no sabemos cuantos sean por lo que los incializamos en un arreglo
    protected $parametros = [];
    //Tenemos ya el inicio de la parte de lo elementos de lo que conforma la URL

    //Ejemplo si tubieramos un nobre de dominio pw2023m.mx/(llamamos al controlador)usuarios/(lo que va hacer, Metodo)agregar/(Siguen los argumentos)1/luis/....

    //  vamos a mandar alllamr el metodo de abajo con el contructor
    public function __construct(){
        // estamos en la msima clase por eso es $this->
        $url = $this->getURL();// aqui va a recibir el arreglo del metodo getURL

        //Vamos a validar el arreglo $url. si vamos hacer referencia a un controlador cargamos este, si es un metodo, hacemos uso del metodo ya con el controlador cargado (que esta dentro de una clase)
        // si existe el archivo que este en la URL subindice cero porque se supone que esta en la pocicion 0 ell controlador
        //estamos en libraries, y los controladores estan en su carpeta, por que hay que ir ahi
        // dentro de conroller buscamos el nombre del archivo y ese con su extencion php
        //hay que asegurarnos que el nombre de archivo con el metodo 'ucwords()' para que busce en mayuscula el primer cracter de cada palabra en una cadena
        /* Dio error porque elrrgelo no existe por lo tanto hay que validar
            Preguntamos si existe URL
        */
        if($url){
            if(file_exists(APPROOT.'/controllers/'.ucwords($url[0]).'.php')){
                /*
                    si tenemos el controlador actual que es 'HOME', pero si le damos otro nombre, entonces
                    camibia al valor la variable
                */
                $this->controladorActual=ucwords($url[0]);
            }
            /* Esta es una convencion de ir quitando los subindices del arreglo que se este utilizando */
            # Vamos a limpiar parcialmente el arreglo $url, con esta funcion
            unset($url[0]);// limpiamos solo ese subindice
        }
        # Cargamos el COntrolador
        // include_once para asegurarnos  que lo carge una sola vez y donde esta el controlador, lo carga el nombre y la extenciona
        /* VAMOS A IR A LA PARTE INTERNA PONEMOS: APPROOT */
        include_once APPROOT.'/controllers/'.$this->controladorActual.'.php';
        # ya cargado el controlador creamos una instancia de esa clase (controlador)
        $this->controladorActual = new $this->controladorActual;// ese msmo nombre de la variable es ahora un objeto, aprovechamos el mismo nombre
        # Validar el metodo (es el segundo elemntos de la URL)
        /*puede ser que en nuestr url ubiera o no un segundo elemento e incluso un controlador puede que no este, y este vacio y no asigne nada y el que se carge sea el controlador por default 'home'
        y si no hay index ya lo tenemos previsto con lo que se cargara lo qu este en el metodo actual 
        
        preguntamos si esta creada (existe) el segundo elemento de la url
        */
        if(isset($url[1])){
            /* php nos permite identificar si una clase tiene metodos con esta funcion 
            si existe el metodo le pasamos dos argumentos( objeto(clase),nombre del metodo), el segundo elemento seria lo que triga la url, que es el subindice uno
            si no existiera ya tenemos el index que esta definido
            
            Aqui cargamos el metodo que esta en home que en home manda a llamar la vista ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            */
            if(method_exists($this->controladorActual,$url[1])){
                /* Si existe el metodoActual ahora no va a ser 'index', cambia a otro valor que tenga */
                $this->metodoActual = $url[1];
            }
            # Vovemos a limpar la parte del arreglo que ya usamos
            unset($url[1]);
        }
        # Vamos con los Parametros (tercer elemento de la url)
        /* puede o no quedar algo que este tercer elemento, por lo que hay que asegurarnos 
         Ya teniams este arreglo como vacio, vamos a verificar si sigue estando vacio, Preguntamos si la $url todabia tiene elementos
            si tiene algo, lo que tenga lo convertimos en un arreglo subindisado, con la funcion: array_values(), nos retorna todos los valores en un solo arreglo
            hacemos esto porque no sabemos el numero de elementos que tiene la $url, por eso ahora convertimos en un arreglo subindesado
            y si no hay nada que se siga manteniendo en un arreglo vacio con []*/
        $this->parametros = ($url)?array_values($url):[];
        # Ahora la URL debe ejecutarse, debe hacer la llamada en este caso _GET o POST, depende como la llamams, es la llamda al recurso acompañada de los argumentos
        /* todos los argumentos que sacamos arriba (controlador,metodo,parametros), para estonos auxiliamos de una funcion
        call_user_func_array(), al final tiene array porque es lo que le vamos a enviar como argumentos,esta funcion requiere dos elemntos obligatorios y uno opcional, son el Controlador,metodo y parametros (en un arreglo)
        como el parametro y metodo no forman parte de un arreglo lo ponemos en un arreglo y si son arreglo lo enviamos de forma directa si son un arreglo, el controladorActual (este no es un arreglo, es un objeto) ni el metodo (es una cadena), entonces los metemos en un arreglo*/
        call_user_func_array([$this->controladorActual, $this->metodoActual],$this->parametros);
        // Esto fue a parte de las URL Amigables
    }

    //Meodo para tomar la URL
    public function getURL(){
        /*
            Ahora si usamos POST los datos no estairan llendo por la url
            por tanto necitamos GET
        */
        // Si esta configurada, la varirable _GET, tomamos la URL
        if(isset($_GET['url'])){
            // Nos aseguramos que traiga un formato, de acuerdo a lo que pedimos como seguridad, esta palabra 'url' viene del archivo htaccess dentro de la carpeta public
            $url = rtrim($_GET['url'],'/');//primero verificar si tiene espacios adicionales, con esta quitamos todos los caracteres que estan al final de la cadena, r de right, pusimos si hay espacios en blanco despues de la ultima diagonal '/'
            // esta funcion nos permite hacer una comparacion con el tipo de variable con lo que deceamos,que enverdad sea una URL
            $url = filter_var($url,FILTER_SANITIZE_URL);//aseguramos que la URL tnega un formato de URL (http://), si es correcto nos regresa un boolean
            //Ahora separar la URL en cada Componente, porque nececitamos diferenciar entre lo que es el controlador, Metodo, Parametros (argumentos)
            $url = explode('/',$url);//estamos usando la misama variable, esta funcion, nos convierte la cadena en un arreglo, y le decimos que cuando se encuentre una '/' que lo separa y lo pona en un subindice en la varaible $url
            // Separamos las cadenas de la url por cada / y lo pone en subindice diferente
            return $url;
        }
    }
}