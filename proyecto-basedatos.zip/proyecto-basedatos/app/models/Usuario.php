<?php
echo 'INGRESO A Usuario.PHP de model';
class Usuario{// no es necesario usar extends porque base ya esta cargao
    private $db;//variable de tipo privado para recivir los datos de la base de datos
    public function __construct(){
        $this->db = new Base;// ya podemos hacer uso de las instruccion en la base de datos
    }

    // Este es el modelo para la interaccion con la base de datos y se hace atravez del modelo y sea mas facil el manetinimiento
    /* Crear el metodo Login */
    public function login($usuario_uid,$usuario_password){
        //Vamos a buscarlos en la tabla de la BD.
        /* Nececitamos un Sentencia SQL, enviarla a la conexion con la base de datos, que tenemos el metodo query que nos prepara la consulta y con bind asociamos y con execute la ejecutamos */
        //Hacemos la llamada con la instancia de la BD(db), le enviamos la consulta
        $this->db->query('SELECT usuario_id,usuario_uid,usuario_nombre,usuario_password,usuario_email FROM usuarios WHERE usuario_uid=:usuario_uid  ');// Ponemos los datos de la tabal que nos interesa,Despues del WHERE (es parte de PDO para evitar la inyeccion de SQL) usuario_uid podemos repertir la variable porque la diferencia con los ':'
        //El passworrd no lo validamos aqui porque lo tenemos que convertir a algo de encriptacion

        #VINCULACION
        /*nececitamos un valor,en este caso con su varaible,(Vinculamos la variable de PDO con la tenemos en la llamada del metodo) Para hacerlo */
        $this->db->bind('usuario_uid',$usuario_uid);//leida en la parte de PDO
        
        //Esperamos recibir segun el metodo, unico,multiple, en este caso solo es un registro por eso usamos unico
        $registro=$this->db->unico();//La vamos a recibir en una variable para poder validar

        //Validar si devolvio un registro, usando el metodo conteoReg
        if($this->db->conteoReg() > 0){
            echo('devolvio un registro');
            //Tambien puede haber un falso si no concuerdo el password
            /* Verificar el password que esta encriptado */
            $hashedPassword = $registro->usuario_password;//Se usa una funcion hashed de encriptacion, si recibimos valores en registro de usuario_password
            /* esta esta funcion nos converte en hash que nos veirifca que lo que tengmos en la variable es compatible con la barible encriptada hashed */
            if(password_verify($usuario_password,$hashedPassword)){
                echo('Contraseña correcta');
                return $registro;//este es el que nneecitamos pero tambien se asocia como TRUE
            }else{
                return false;
            }
        }else{
            //si es falso, retornamos
            return false;//Este lo recibe $logueado en Usuarios.php
        }

    }
    /* Metodo usado en Usuarios.php */
    public function encontrarUsuarioPorEmailoIdUsuario($usuario_email,$usuario_uid){
        //Este nos tiene que regresar un falso o un verdades segun si existe
        // Requerimos
        #sentencia
        $this->db->query('SELECT usuario_email,usuario_uid FROM usuarios WHERE usuario_email= :usuario_email OR usuario_uid= :usuario_uid');//verificamos si existe uno u otro
        #vinculacion (En este caso son dos porque son dos variables)
        $this->db->bind(':usuario_email',$usuario_email);
        $this->db->bind(':usuario_uid',$usuario_uid);
        #Ejecucion
        //Nececitmaos solo un unico registro
        $registro=$this->db->unico();
        //Con que nos retorne un unico registro es false, contando los registro
        return($this->db->conteoReg()>0)?true:false;

    }

    /* retorna false si no registro y retorn true si registro */
    public function register($data){
        /* Vamos hacer sentencias SQL, la vinculacion y ejecucion(Nos deve enviar) */
        #vamos insertar, le agregamos :  a los parametros
        $this->db->query('INSERT INTO usuarios (usuario_uid,usuario_nombre,usuario_password,usuario_email) VALUES (:usuario_uid,:usuario_nombre,:usuario_password,:usuario_email)');
        #Vinculacion
        /* Le establecemos a cada parmetro su variable correspondiente en el arreglo */
        $this->db->bind(':usuario_uid',$data['usuario_uid']);
        $this->db->bind(':usuario_nombre',$data['usuario_nombre']);
        $this->db->bind(':usuario_password',$data['usuario_password']);
        $this->db->bind(':usuario_email',$data['usuario_email']);
        #Ejecucion (No es una consulta(SELECT)),(estamos insertando datos) este es un execute directo, con el metodo execute que hizimos
        try {
            //Cuando hacemos una ejecucuion en un INSERT nos regresa un numero de registro, si inserta true (1 reistr) o false (0 registro)
            $this->db->execute();
            return true;
        } catch (Exception $e) {
            return false;
        }
        
        //return ($this->db->execute())?true:false;//depende de como salga la ejecucion
        /* Limpiar la tabla,En la Pestaña, Operaciones, al final esta VACIAR la Tabla */
    }
}

/* Como hacer que al logearse, este en otra pantalla adentro
Tenemos una variabe, SSECION,Usuario
1° Verificar en la parte del modelo cunado usaemos el metodo de CrearSesionUsuario
    Para hcerlo de forma global tenemos el metodo logueado, si el asociado de esa super global quiere decir que paso por un proceso de validacion y se creo la sesion
Vamos a cambiar la vista, con login y registrar eso cambiara porque ya pasamos los filtros de Ingresar al sistema
    y registrar cambir a logout (Salida),     */
