<?php

class Cliente{
    //Creamos una variable para maneja rla instancia de la base de datos
    //es la que nos hace la union al menjo de datos, es la conexion
    private $db;
    public function __construct()
    {
        $this->db=new Base;//nos unimos a base, (-automatica es con el constructor)
    }

    public function listadoClientes($limite,$pagina){
        # Menjo de la Paginacion
        /* cambio a comillas "" el query para manejar variables 
        usamos limit: para determinar el numero de registros que debe desplegare solo registros por pagina 
        pagina = es una vista parcial (va haber tantas como registros haya)
        offset = le damos un valor (5, cuenta del incio del arreglo 0 hasta el valor 5 y empieza a desplegar desde el 6), seria el salto de n registros, se obtiene (numero de paginas - 1)* limit*/
        $offset = ($pagina - 1)*$limite;//Estos son los argumentos que recibimos en el metodo
        # Debemos conocer el total de registro de la tabla
        // haciendo uso de las consultas de la base de datos
        $this->db->query('SELECT count(*) as registros FROM clientes');// contamos todos los registros ese valor registro lo metemos en su variable registros
        $registros = $this->db->unico()->registros;//Solo es un registro usamos unique y como nos devuelve el asociado que le ponemos registros (Aqui ya sabemos cuantos registros son)
        //con la variable de arriba sacamos cuantas paginas
        /* las paginas la nececitamos porque vamos a utilizar un navegador de paginas (navegador de paginacion), las paginas hay que redondearlas hacia arriba es decir si tenemos
        dos registros y las mostramos en limite de 10 si la redondemaos de abajo no  veriamos el registro 101 y 102, entonces lo hacemos hacia arriba */
        # Redondear Arriba
        $paginas = ceil($registros/$limite);//ceil() nos redondea las fracciones hacia arriba, vamos dividir registro entre limite y ya tenemos las paginas

        
        //Aqui hacemos un consulta a la BD, vamos a seleccionar todos los campos (Si estamos regresando la fotografia)
        $this->db->query("SELECT id,cliente_rfc,cliente_nombre,cliente_direccion,cliente_email,cliente_telefono,cliente_fotografia FROM clientes LIMIT $offset,$limite");
        // Tenemos un archivo de clientes en sql para ingresar a la tabla de la base de datos, copia todo el texto y en phpyadmin se pega
        //en este caso la fotografia se lleno con un dato con null

        # No hay vinculacion
        # Debe haber ejecucion (son los resultados), regresamos datos y los recibi clientes (el nombre puede ser cualquiera)
        // si debe de ser tipo array porque la vista esta preparada para ello ya que el metodo view de controller.php recibe un arreglo
        // La ejecucion es con multiple porque esperamos muchos registros
        $data['clientes'] = $this->db->multiple();

        # Creacion de arreglo con asociados (Con la variavles que estamos trabajando arriba) que se pasan al index.php en la paginacion
        $paginacion = [
            'limite'    => $limite,
            'registros' => $registros,
            'pagina'    => $pagina,
            'paginas'   => $paginas,
            'pag_previa' => ($pagina-1),//Esto se les agrego para el previus y next de la paginacion de bootstrap
            'pag_siguiente' => ($pagina+1),
        ];//Ya tenemos los datos para la paginacions

        /* Uso de la funcion que junta arreglos, generando un solo arreglo*/
        # Vamos a juntar los dos arreglos con esten metodo
        $data = array_merge($paginacion,$data);// Estamos reutilizando varaible $data

        /* HACEMOS PARA DEBUG 
        echo '<pre>';
        print_r($data)*/
        /* para ver los datos de la fotografia, vemos el encabezado de la imegen que nos dice el formato, no podemos identificar a solo que usaemos una funcion 
        en index.php*/

        return $data;// lo va a recibir clientes del metodo index
    }
    //Verificar si ya exite el RFC o Email registrados
    public function encontrarClientePorEmailoRFC($cliente_email,$cliente_rfc){
        //Este nos tiene que regresar un falso o un verdades segun si existe
        # Requerimos
        $this->db->query('SELECT cliente_email,cliente_rfc FROM clientes WHERE cliente_email= :cliente_email OR cliente_rfc= :cliente_rfc');
        #vinculacion (En este caso son dos porque son dos variables)
        $this->db->bind(':cliente_email',$cliente_email);
        $this->db->bind(':cliente_rfc',$cliente_rfc);
        #Ejecucion
        //Nececitmaos solo un unico registro
        $registro=$this->db->unico();
        //Con que nos retorne un unico registro es false, contando los registro
        return($this->db->conteoReg()>0)?true:false;

    }

    /* Metodo para agregar un nuevo Cliente */
    public function agregar($data){
        #vamos insertar, le agregamos :  a los parametros
        $this->db->query('INSERT INTO clientes (cliente_rfc,cliente_nombre,cliente_direccion,cliente_email,cliente_telefono,cliente_fotografia) VALUES (:cliente_rfc,:cliente_nombre,:cliente_direccion,:cliente_telefono,:cliente_email,:cliente_fotografia)');
        #Vinculacion
        $this->db->bind(':cliente_rfc',$data['cliente_rfc']);
        $this->db->bind(':cliente_nombre',$data['cliente_nombre']);
        $this->db->bind(':cliente_direccion',$data['cliente_direccion']);
        $this->db->bind(':cliente_telefono',$data['cliente_telefono']);
        $this->db->bind(':cliente_email',$data['cliente_email']);
        $this->db->bind(':cliente_fotografia',$data['cliente_fotografia']);
        
        try {
            $this->db->execute();
            return true;
        } catch (Exception $e) {
            return false;
        }
        
    }

    //Metodo Editar (Nos retorna el registro si existe)
    public function editar($id){
        # Requerimos todos los campos
        $this->db->query('SELECT id,cliente_rfc,cliente_nombre,cliente_direccion,cliente_email,cliente_telefono,cliente_fotografia FROM clientes WHERE id = :id');
        #vinculacion
        $this->db->bind(':id',$id);
        /*
            (Debug o demostracion) Verificamos la ejecucion para ver que nos esta regresando
            echo '<pre>';
            print_r($this->db->unico());
            Al darle cicl al boton editar vemos que si esta haciendo la consulta, con el cleinte con foto vemoc como nos regresa la imagen
            con todos esos caracteres
        */
        #Ejecucion
        return $this->db->unico();
    }

    /* Actulizar */
    public function actualizar($data){
        #vamos update usando el ID oculto en el POST
        $this->db->query('UPDATE clientes SET cliente_rfc = :cliente_rfc ,cliente_nombre = :cliente_nombre,cliente_direccion = :cliente_direccion,cliente_email = :cliente_email,cliente_telefono = :cliente_telefono,cliente_fotografia = :cliente_fotografia WHERE id = :id');
        #Vinculacion
        $this->db->bind(':id',$data['id']);
        $this->db->bind(':cliente_rfc',$data['cliente_rfc']);
        $this->db->bind(':cliente_nombre',$data['cliente_nombre']);
        $this->db->bind(':cliente_direccion',$data['cliente_direccion']);
        $this->db->bind(':cliente_telefono',$data['cliente_telefono']);
        $this->db->bind(':cliente_email',$data['cliente_email']);
        $this->db->bind(':cliente_fotografia',$data['cliente_fotografia']);
        
        try {
            $this->db->execute();
            return true;
        } catch (Exception $e) {
            return false;
        }
        
    }
    /* Borrar (Se peude mandar a llamr a una vista que pregunte si estamos seguros de BORRar) */
    public function borrar($id){
        #consulta (borramos por su id)
        $this->db->query('DELETE FROM clientes WHERE id=:id');
        #Vinculacion
        $this->db->bind(':id',$id);
        #Ejecucion
        try {
            $this->db->execute();
            return true;
        } catch (Exception $e) {
            return false;
        }

    }
    /**
     * 
     * Listar los cleintes sin paginar
     *  */ 
    public function listarClientes(){
        # Consulta (no nececitamos ningun where porque queremos todos)
        /* No es RECOMENDABLE hacer esto para el archivo JSON, usamos una funcion (que puede no estar disponibe para otros SGBD) para el campo fotografia (cliente_fotografia) 
        Covertimos el campo a Base64, TO_BASE64()AS CON ESTA CONVERSION ya podemos leer el archivo JSON*/
        $this->db->query('SELECT id,cliente_rfc,cliente_nombre,cliente_direccion,cliente_email,cliente_telefono,TO_BASE64(cliente_fotografia) AS cliente_fotografia FROM clientes');
        #Vinculacion

        #Ejecucion 
        $data['clientes'] = $this->db->multiple();// ya que este nos regresa datos
        /* Retornar la variable arreglo que usa la tabla que imprmes los clientes */
        //$data['clientes'] = $this->db->execute(); (Este no es correcto solo cuando es INSERT)
        return $data;
    }

    /*********************************************************************************************************
     *  OTRA UNIDAD
     * 
     */
    public function consultaCliente($id){
        # consulta
        $this->db->query('SELECT cliente_nombre FROM clientes WHERE id=:id');
        # vinculacion
        $this->db->bind(':id',$id);
        # ejecucion

        //lo retornamos como objeto
        return $this->db->unico();
    }
    ///////////////// Profe Confudido
    /**
     * Servicios web con SOAP
     */
    public function consultaClienteSOAP($id){
        # consulta
        $this->db->query('SELECT cliente_nombre,cliente_direccion,cliente_email FROM clientes WHERE id=:id');
        # vinculacion
        $this->db->bind(':id',$id);
        # ejecucion

        //lo recivimos en una variable
        $cliente = $this->db->unico();

        //(la ejecucion lo convertimos a arreglo) lo enviamos como arreglo ya que la entrada se le envia como arreglo en Servicios.php
        return [
            /* le ponemos otros nombres para que vean el comportamiento  */
            'nombre' => $cliente->cliente_nombre,// esto como es la parte de la vista
            'direccion' => $cliente->cliente_direccion,
            'correo' => $cliente->cliente_email
        ];//cada uno de estos va a ser la salida
    }



}// en esta parte del modelo tenemos el CRUD completo

/* Falta generar un PDF (documento imprimido), PHP tiene varias funciones  
    o librerias pero el propio PHP tiene funciones aunque es muy largo por este proseso
    FPDF requiere mucho trabajo para generar PDF's

    A usar mas rapido es 'DomPDF' a partir de HTML se convierte a PDF
    , hay librerias con el manejo de BD de manera externas

    Se descarga de github, pegamos el archivo en el proyecto, lo descomprimimos

    DoomPdf: Nos crea documentos PDF

    En la carpeta vendor se ponen todas las aplicaciones de otros proveedores en src tenemos todas esas clases que nos dan la conversiom de
    PHP a PDF, una carpeta con clases relacionadas se llama espacio de nombre
*/