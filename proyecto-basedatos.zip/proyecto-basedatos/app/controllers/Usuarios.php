<?php
echo 'INGRESO A Usuarios.PHP';
/* Al controlador le habiamos puesto Usuarios */

class Usuarios extends Controller{// hereda con controllers poruqevamos a trabajr conla vista y el modelo
    /* aqui usamos los datos de la base de datos */
    public function __construct(){
        //le pasamos el nombre del modelo,(CONVENCION) si tenemos un controlador en plural, el modelo lo ponemos en singular, e este caso Usuario
        $this->usuarioModel = $this->model('Usuario');//el (Metodo) modelo nos regresa una instancia del modelo y lo tenemos que recibir en una variable
    }

    //Cuando no exista un metodo pordefecto se va a este metodo
    public function index(){
        $this->view('/construccion');
    }

    #Creacion del Modelo en la carpeta modelo con el nombre Usuario.php
    /* nos manda a llamar una vista, este metodo se manda a llamar en el menu GET(Muestra la interfaz) y despues por POST(hace las validaiones), si todo va bien hace una sesion de ususario */
    public function login(){
        //Nos presente la vista que esta en usuarios y se llama login
        // para hacer la presentacion de la vista sera desde el menu (GET), proceso de datos, formulario (post)
        # Definicion de $data, de tipo arreglo que lleve los datos
        $data=[
            //los del formulario, donde pusimos los nombre de los campos en login.php
            'usuario_uid'      =>'',
            'usuario_password' =>'',
            //vamos abuscar un apoya para validar, si ocurre un error tenemos este para mensaje
            'msg_error'=>''
        ];
        # Diferenciar si hubo llamada de menu o fomulario, Lectura de las Superglobales y que maneja la super global Server
        // asi se checa si vienede GET o vienen de POST
        if($_SERVER['REQUEST_METHOD']=='POST'){//si es POST viene del formulario
            //Aqui se explica mas abajo
            $_POST=filter_input_array(INPUT_POST,FILTER_SANITIZE_STRING);
            /* Sabemos que viene una superglobal con DATOS, vamos a recibir esos datos con estas variables */
            $data=[
                //Podemos usar esar superglobales pasandoles sus datos del fomularios
                'usuario_uid'      =>$_POST['usuario_uid'],
                'usuario_password' =>$_POST['usuario_password']
            ];
            //Lo que nos interesa validar, puede sucedir que los datos vayan vacios, que el pass o usaurio o los dos no concuerden con la base de datos
            //1° Que los campos no esten vacios
            if(empty($data['usuario_uid']) || empty($data['usuario_password'])){//podemos poner el arreglo $data o POST
                //Asignamos un valor en la aprte de msgError
                $data['msg_error']='Llene todos los campos';
            }
            //2° Esta tiene que ver con el modelo, verificar si existen esos datos en la tabla de BD
            /* primero deben estar llenos los campos entonnes el msgError debe estar vacio */
            if(empty($data['msg_error'])){
                echo('Va a crear la Sesion');
                /* Vamos a intervenir con el modelo, en ese se crea un metodo login que se le envia el usuario y password (Vamos a crear este modelo) */
                $logueado = $this->usuarioModel->login($data['usuario_uid'],$data['usuario_password']); //vamos a recibir ciertos drespues tde consultas que hagamos en la base de datos (TRUE o FALSE)

                // Continuamos en el controlador que nos regresa un registro o un FALSE
                # 1° que no venga un false
                if($logueado){
                    //creamos una sesion
                    // usamos en metodo creado aqui mismo
                    $this->crearSesionUsuario($logueado);#con los datos de logeado
                }else{
                    $data['msg_error']='Password/Usario no es correcto';
                    //$this->view('usuarios/login',$data);// ponemos la vista con esos datos
                }
            }
        }
        $this->view('usuarios/login',$data);
    }
    public function register(){
        //Va hacer cparecido que el de login 
        $data=[
            //los del formulario, donde pusimos los nombre de los campos en login.php
            'usuario_uid'      =>'',
            'usuario_nombre'      =>'',
            'usuario_password' =>'',
            'confirmacion_password'      =>'',
            'usuario_email'      =>'',
            //vamos abuscar un apoya para validar, si ocurre un error tenemos este para mensaje
            'msg_error'=>''
        ];
        # Diferenciar si hubo llamada de menu o fomulario, Lectura de las Superglobales y que maneja la super global Server
        // asi se checa si vienede GET o vienen de POST
        if($_SERVER['REQUEST_METHOD']=='POST'){//si es POST viene del formulario
            #Hay que asegurarse que venga de forma correcta
            #Esta Parte vamos a filtrar con el proposito de sanitizar(que se cumple con lo que se pide)
            #Recibira de entrada(INPUT del POST) y lo sanitizamos por STRING
            $_POST=filter_input_array(INPUT_POST,FILTER_SANITIZE_STRING);

            /* Sabemos que viene una superglobal con DATOS, vamos a recibir esos datos con estas variables */
            $data=[
                //Podemos usar esar superglobales pasandoles sus datos del fomularios
                'usuario_uid'               => $_POST['usuario_uid'],
                'usuario_nombre'            => $_POST['usuario_nombre'],
                'usuario_password'          => $_POST['usuario_password'],
                'confirmacion_password'     => $_POST['confirmacion_password'],
                'usuario_email'             => $_POST['usuario_email'],
            ];
            //Lo que nos interesa validar, puede sucedir que los datos vayan vacios, que el pass o usaurio o los dos no concuerden con la base de datos
            //1° Que los campos no esten vacios
            if(empty($data['usuario_uid']) || empty($data['usuario_password']) || empty($data['usuario_nombre']) || empty($data['confirmacion_password']) || empty($data['usuario_email'])){//podemos poner el arreglo $data o POST
                //Asignamos un valor en la aprte de msgError
                $data['msg_error']='Llene todos los campos';
            }
            # Se pregunta si se cumple la confirmacion del Password sea igual al Password
            if($data['usuario_password'] != $data['confirmacion_password']){
                $data['msg_error']='El Password no Coincide';
            }
            /**
             * Poner todas las validacion correspondientes a politicas de creacion de password 
             * y de ID de usuario ------- pueden usar exprecciones regulares(patterns)
             */
            #Validarr el formato de correo(email)
            if(!filter_var($data['usuario_email'],FILTER_VALIDATE_EMAIL)){//Con esta funcion negada, le pasamos del arreglo el email y por el filtro del EMAIL
                $data['msg_error']='El formato de email no es correcto';
            }

            #Validar la no existencia de id Usuario y/o email
            /* aqui se usa el modelo, se nececita crear un metodo en un modelo para usar eso 
            Vamos a validar con una busquedad en la base e datos para buscar*/
            if($this->usuarioModel->encontrarUsuarioPorEmailoIdUsuario($data['usuario_email'],$data['usuario_uid'])){
                $data['msg_error']='Email y/o Usuario ya esta registrado';
            }
            //Ya podemos validar el mensaje de error
            //2° Esta tiene que ver con el modelo, verificar si existen esos datos en la tabla de BD
            /* primero deben estar llenos los campos entonnes el msgError debe estar vacio */
            if(empty($data['msg_error'])){
                //Vamos hacer registro de datos, le enviaremos todos los datos
                /*1° Encriptar el password (Pasarlo por una funcion hash) */
                $data['usuario_password']=password_hash($data['usuario_password'], PASSWORD_DEFAULT);//usamos esta funcion de PHP (nos crea la encriptacion de password), como segundo parametro es el formato a dar
                /*2° (Validar el envio del registro) Hay que registrarlo, si todo es OK hayq ue esperar un true*/
                /* hacemos uso de un metodo en el model, le enviamos todo el arreglo para que lo registr */
                if($this->usuarioModel->register($data)){
                    //ya que esta registrado lo redirigimos al login para logearse------------------------------------------------------------------------------------------------------------------------------
                    redirigir('/usuarios/login');//donde esta login
                }else{
                    //Si hubo un error
                    $data['msg_error']='Error al registrarse';
                }
            }
        }
        $this->view('usuarios/register',$data);
    }

    public function crearSesionUsuario($usuario){
        //Vamos a usar la superglobal $_SESSION, la vamos a incializar mas adelante en otra parte
        //la otra parte es en (helpers.php)
        #al usarla nos crea una sesinon, un estado para verificar si estamos autorizados si podemos hacer algo o no o conservar variables de tipo global y poder usarlas en el cuauquier parte del sistema
        $_SESSION['usuario_id']=$usuario->usuario_id;//Usando la variable le asociamos el elemento que tenemos en el registro (lo que nos interesa lo conservamos)
        $_SESSION['usuario_nombre']=$usuario->usuario_nombre;
        $_SESSION['usuario_email']=$usuario->usuario_email;//Estos datos es con el propocito de manejar su nombre y correo en algun momento
        /* En helpers see crea la sesion o si nodara error */
       //(Si todo ya se hizo bien) Ya no queremos la ventana de login, queremos que nosmuestre la ventana incial
        //Regdigir a otra Vista, Mejor usando la funcion Header en helpers.php
        # Le decimos que nos lleve a '/'index por la url: pw20213m.mx/index (Redirigir a otra vista de manera controlada)
        redirigir('/index');//Creamos este metodo como el comando header nececita un location, esta funcion estara en helpers
    }

    //Metodo para salirse de la sesion
    public function logout(){
        //Destruir los datos de la session y redireccionar (a login)
        # Para borrar datos del arreglo, con unset(Elimina ese asocias)
        unset($_SESSION['usuario_id']);
        unset($_SESSION['usuario_nombre']);
        unset($_SESSION['usuario_email']);
        
        #Redirecciona a:
        redirigir('/usuarios/login');
    }
    
}