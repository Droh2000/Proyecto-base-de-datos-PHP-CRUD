<?php
/* Este es nuestro constrolador Inicial */
class Home extends Controller{//Manejar los metodos de vista
    /* primero nos aticipamos si tenemos que cargar algo automatico con el constructor */
    public function __construct(){

    }
    //metodo que mande a llamar a la vista 
    public function index(){
        $data=['Bienvenido'];
        //Crgamos la vista principal,solo le mandamos el nombre del archivo
        $this->view('index',$data);
    }
    /*
        Solo index porque si nos vamos a Controller.php en libraries en el metodo view recibe index y le concatena .php
        en la carpeta view busca ese arhivo index.php y lo incluye que dentro esta el header y footer
    */
}