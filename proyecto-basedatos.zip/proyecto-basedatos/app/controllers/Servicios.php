<?php
/**
 * Para la Creacion de un Servicio (Este es el controlador)
 *  Se nececita:
 *      Un controlador
 *      Si se va a accesar a una BD se necesitaria un modelo
 *      Se nececita una forma de ingresar (No seria con una vista), aqui solo le vamos a ingresar datos
 * 
 * Prueba de generacion de un servicio web con SOAP
 * Requerimos:
 *  Cliente (Que lo consuma) -----------------------------------> servidor
 * Metodos:
 *  index sera para cliente
 *  server para servidor
 */

 class Servicios extends Controller{// como vamos a usar modelos o vistas nececitamos el controller
    public function __construct(){
        $this->clienteModel = $this->model('Cliente');
    }
    /* Creacion del metodo index (nos aseguramos que reciva un valor si en caso de que no le ponga 0) */
    public function index($id = 0){
        # crear la instancia (nececita como parametro done esta la ubicacion del servidor)
        $client = new nusoap_client(URLROOT.'/servicios/server');
        //el resultado usa el cliente que llame al metodo que se definio en el servidor
        // le enviamos este valor en un arreglo ya que requiere de esto
        $result = $client ->call('Cliente.consultaClienteSOAP',['id'=>$id]);
        //Poner el resultado como nos lo represente (Falta capturar posibles errores)
        /*header('Content-type: application/json');
        echo json_encode($result);*/

        #DEmos para debug y conocimiento de comuunicacion SOAP
        //Vamos a ver como lo esta regresando
        echo '<h2>Encabezado de la Requisicion (Request)</h2>';
        /* Trabajar con un metodo de nusoap par que hicicera esto, mandarlo preformatido <pre> 
            cuando hacemos la llamada del lciente al servidor va al request y cuando responde es el responce
            (ver como hace la paeticion al servidor), el request puede ir con caracteres que no se despliega con caracteres
            entonces se pone entre () para que los caracteres especiales los ponga en caracteres especiales y se le pasa otro
            argumento ENT_QOUTE*/
        echo '<pre>'.htmlspecialchars($client->request,ENT_QUOTES).'</pre>';
        /////////// ¿Cuando puso esto?
        echo '<h2>Encabezado de la Requisicion (Response)</h2>';
        echo '<pre>'.htmlspecialchars($client->response,ENT_QUOTES).'</pre>';
        ////////////Expicacion del formato WSDL  con soap 

    }// con la URL vemos como nos regresa los datos

    // Creacion de Servidor
    public function server(){
        /**
         * Hay varias formas de configurar
         */
        # Crear la Instancia del server con nusoap (nos auxiliamos con este porque el WSDL es dificl crear manualmente)
        $server = new nusoap_server;// ya tenemos la ayuda porque esta cargada la liberia en autoload
        # configurar
        $serverName = 'Consulta de Clientes por SW';
        $serverNameSpace = URLROOT.'/servicios/server';//(es recomendable que sea la ruta del servidor)poner un  espacio de nombre (NameSpace)

        /* DEFINICION DE DATOS COMPLEJOS (tns): cuando lleva mas de un valor a definir */
        $server->wsdl->addComplexType(
            'DatosArticulo',//El nombre del dato
            'complexType',//definir de tipo complejo (que va a ser una mezcla de tios dados en un arreglo)
            'struct',
            'all',
            '',
            //Arreglo dodne se van a definir los datos a recivir
            [
                //Que es lo que estamos recibiendo
                //se tienen que definir el tipo con el que se va a tratar
                'nombre'=>['name'=>'nombre','type'=>'xsd:string'],//Esto es difrente con los datos simples ya que se pone, nombre del atributo,el tipo (si es cadena xsd:string)
                'direccion'=>['name'=>'direccion','type'=>'xsd:string'],
                'correo'=>['name'=>'correo','type'=>'xsd:string'],
            ]
        );//vamos agregar una definicion de un tipo complejo

        # Configurar el WSDL -- Esto es el header (como si fuera el encabezado)
        //Usando la instancia usamos este metodo con los dos valores de arriba
        $server->configureWSDL($serverName,$serverNameSpace);
        //Con esto ya podemos empezar a crear el Cuerpo
        # AHORA TRABAJR CON EL BODY (Parte de registrar el metodo en el modelo donde se contruye la BD)
        // se hace con el metodo register que da a conocer a la tecnologia lo que se le tiene que dar
        $server->register(
            //del . hacia tras seria el modelo y lo demas el nombre del metodo (Uso de objetos)
            'Cliente.consultaClienteSOAP',//(Libreria donde va a ser llamado), Se le da el nombre de un metodo == funcion que es lo primero que se tiene que dar es decir a que lenguaje de logica de negocio va a recurrir basado en una funcion
            /* como la entrada va a ser un arreglo, lo que enviamos 'id'(nombre de la variable y su tipo) no es (la asignacion de valor), aqui estmamos construyendo el WSDL(con ayuda de la libreria) 
                a esta varaible se le va a asginar un valor mas adelante*/
            ['id'=>'xsd:int'],// como formato de arreglo le pasamos la [entrada]
            /* para la salida (Debe ser un arreglo), la funcion nos regresa con el identificador 'return' y la salida la vamos a preparar ya que cada elemento decimos de que tipo es   
                con tns, le decimos que es un objeto complejo (tns) con el de arriba es un singular y aqui es un grupo de variables de un conjunto

                se va a definir: nombre.direccion,email (tiene aon una relacion con su tipo de dato correspondiente)
                */
            ['return' => 'tns:DatosArticulo'],//igual en arreglo para determinar el tipo de [salida]
            /* Faltan otros argumentos 
            El namespace ya la definimos con la variable de arriva*/
            'urn: '.$serverNameSpace, //namesapce, a este tambien se le pone un indetificador (Opcional)
            'urn: '.$serverNameSpace.'#consultaCliente', //SOAPACTION, para diferenciarlo del de arriba se le concatena un identificador
            /* como SOAP esta oasociado a procediemtos de llamada remota, esta la base de operacion con SOap */
            'rpc',//style
            'encoded',//use, se puede trabajar codificado o no codificado
            'Consulta datos de Cliente',//documentacion (Es una desripcion de lo que esta haciendo)

            
        );// Es oblihatorio el formato de arreglo

        # Invocar el SERVICIO
        /* cunado leemos datos de un archivo fisico se usa File_get_contents, como aqui tenemos la consulta
            enviamos el ID en a que madamos a llamar
            
            la forma de regresarlos, usamos el recurso de PHP para invocar el servicio
            con el metodo service() nos regresa valores, podemos poner algo que viene en el encabezado de forma cruda
            pero mejor se usa la funcion: file_get_contents() que va a tomar lo que traiga en la memoria (regrego de la consulta)
            y eso nos da la respuesta (Lo que hace es tomar los datos de la Memoria y no de un archivo fisico)
        Como esta siendo llamado de memoria, le ponemos un @ para que lo use como apuntador (Use como una referencia) 
        Estamos envindo la entrada a la parte del despliegue
        */
        @$server->service(file_get_contents("php://input"));
    }
    /* Y consturimos el SERVER, no se nececita el cliente para probar, mandamos a llamar a servicios/server
       y vemos lo que nos construye la libreria SOPA, vemos el WSDL (no trabaja con MVC) a dar click no para nada, mejor se pone en la URL
       (hace la llamada al index.php, si puede aprovechar escribirndo wsdl en la URL) asi ver lo que nos contruyo de esta estructura que es simple pero se puede hacer complejo  
        
       Nos falta el Cliente:
        nececitamos un index y luego enviarle un valor
        vamos a contruirlo como metodo aqui primero
       */
 }