<?php

class Clientes extends Controller{// Nececitamo manejar vistas y modelo asi que heredamos de controller
    //Sea de forma automatica el modelo y control
    public function __construct()
    {
        $this->clienteModel=$this->model('Cliente');    
    }

    //este es el motodo que es al que se ira por defecto
    // Manda a llamar el metodo listadoClientes de Cliente.php
    public function index($limite = 10 , $pagina = 1){// Los parametros que necitamos pasar: $limite le ponemos por defecto 10 y $pagina = 1 como la que por defecto se muestra, esos valores tendra al llamar en la URL o Menu
        /* Nuestro limite ahora es de 10 por pagina
         con la url podemos cambiatr de pagina, aqui requerimos de un navegador*/

        //llamada al modelo (Queremos que nos regrese el valor de $data, un arreglo con datos) para eso hacemos una consulta a la tabla de BD
        $clientes=$this->clienteModel->listadoClientes($limite, $pagina);
        /* Vamos a darle a $data el mismo trato, como en situaciones de mensajes
        $data=[
            'mensajes'=>'Mensajes',
            'clientes'=>$clientes,//cuando reciamos data vamos a tener que extraer los clientes de ahi, Este asociado su valor va a ser un objeto '=>'
        ];*/
        //Se quito lo de arriba  porque serian muchos brincos

        # Para debug o demostracion, de lo que estamos recibiendo
        //Nos devuelve un areglo que tiene un asociado clientes y asu ves tiene un objeto  de arreglo
        /*echo '<pre>';
        print_r($clientes);*/
        /* Esto nos devuelve un arreglo que tiene un asociado ['clientes'] y que a si vez ese asociado tiene un arreglo pero cada arreglo es un objeto
        osea cada elemnto del arreglo es un objeto y nos esta devolviendo del 0 al 99 */

        //Le mandamos clientes a la vista, la vista recibe como arreglo
        //Mande a llamar a la vista clientes es donde nos saldra la lista de los clientes
        $this->view('clientes/index',$clientes);// Nos regre el arreglo condatos ($data) para eso nececitamos hacer una consulta a la base de datos, llamaa al modelo para que nos regrese esos datos 

        /*viendo las cosas con la presentacion de todos datos es la 'paginacion': es dividir el contenido en paginas, poner de 10 en 10 de 5 en 5 
            y se fuera dando esa parte estetica, habria que recordar el uso de las instrucciones SQL podemos manejar obset y limit en la consulta para manejar la paginacion */
               
    }

    //Metodo agregar para el boton que nos permite insertar nuevos registros de clientes
    public function agregar(){
        //Cambiamos a cliente los valores
        $data=[
            'cliente_rfc'      =>'',
            'cliente_nombre'      =>'',
            'cliente_direccion' =>'',
            'confirmacion_telefono'      =>'',
            'cliente_email'      =>'',
            'cliente_fotografia'      =>'',
            'msg_error'=>''
        ];

        if($_SERVER['REQUEST_METHOD']=='POST'){
            $_POST=filter_input_array(INPUT_POST,FILTER_SANITIZE_STRING);

            /* Esto es para validar,preguntar por el tamaño si el tamaño es igual a 0 sea vacio y si no valida*/
            $cliente_fotografia= ($_FILES['cliente_fotografia']['size'] == 0 )?'':file_get_contents($_FILES['cliente_fotografia']['tmp_name']);
            //Investigar la funcion (Esta se podria usar arriba): getimageSize(), especifica ai retraemos informacion hacerca de un archivo local

            /* Sabemos que viene una superglobal con DATOS, vamos a recibir esos datos con estas variables */
            $data=[
                //Podemos usar esar superglobales pasandoles sus datos del fomularios
                'cliente_rfc'               => $_POST['cliente_rfc'],
                'cliente_nombre'            => $_POST['cliente_nombre'],
                'cliente_direccion'          => $_POST['cliente_direccion'],
                'cliente_telefono'          => $_POST['cliente_telefono'],
                'cliente_email'             => $_POST['cliente_email'],
                'cliente_fotografia'        => $cliente_fotografia,//empty($_POST['cliente_fotografia'])?'':file_get_contents($_FILES['cliente_fotografia']['tmp_name']),//aqui vamos a trabajar y validarla de manera diferente la imagen, queremos que se guarde en la base dedatos
                /*La imagen se guarde en la base de datos para eso hacemos un uso del formulario que sea multipart (para trabajar con la superglobal FILES que trae de la PC la imagen y subirla la BD)
                    Hay que aseugrarse que haya un archivo que subir, en la parte de POST tenemos cliente_fotografia hay que asegurarse que no vaya vacio:
                    empty() si viene vacio con ? le decimos que asi se quede '' pero si no vamos a utilizar: 
                    file_get_contents() esta funcion toma un archivo fisico convertirlo en binario y subirlo a la base de datos
                    En este caso tomamos los datos que bienen en la super global $_FILES le sacamos el asociado que es lo que le pusimo al INPUT tipo file 'cliente_fotografia'
                    y le ponemos el otro asociado 'tmp_name' que es lo que vamos a buscar es el nombre del archivo fisico que seleccionamos y este biene en un subarreglo, un subasociado
                    entonces esto biene en ['tmp_name'] el nombre temporal que trae el nombre fisico del archivo
                    (CON ESTO VAMOS A SUBIR EL ARCHIVO)
                */
            ];
            
            //1° Que los campos no esten vacios
            if(empty($data['cliente_rfc']) || empty($data['cliente_nombre']) || empty($data['cliente_direccion']) || empty($data['cliente_telefono']) || empty($data['cliente_email'])){//podemos poner el arreglo $data o POST
                //Asignamos un valor en la aprte de msgError
                $data['msg_error']='Llene todos los campos';
            }
            
            #Validarr el formato de correo(email)
            if(!filter_var($data['cliente_email'],FILTER_VALIDATE_EMAIL)){
                $data['msg_error']='El formato de email no es correcto';
            }

            #Validar la no existencia de RFC o email de un lciente para que no se repita
            /* En este caso el nombre del metodo cambio de nombre y por clienteModel
            No podemos agregar un cleinte con el mismo RFC y que no se repita el correo*/
            if($this->clienteModel->encontrarClientePorEmailoRFC($data['cliente_email'],$data['cliente_rfc'])){
                $data['msg_error']='Email y/o RFC ya esta registrado';
            }

            //Ya podemos validar el mensaje de error
            if(empty($data['msg_error'])){
                if($this->clienteModel->agregar($data)){
                    redirigir('/clientes');
                }else{
                    $data['msg_error']='Error al registrarse';
                }
            }
        }
        $this->view('clientes/agregar',$data);// Que nos mande a la vista de agregar
    }

    // Metodo que se manda a llamar con la tabla 
    public function editar($id){
        // Tenemos el GET (recibimos por la URL), POST (no podemos recibirlo porque el argumento va dentro del formulario nada por la URL)
        //En caso de POST es lo priemero a trabajar
        if($_SERVER['REQUEST_METHOD']=='POST'){
            $_POST=filter_input_array(INPUT_POST,FILTER_SANITIZE_STRING);

            /* Esto es para validar,preguntar por el tamaño */
            $cliente_fotografia= ($_FILES['cliente_fotografia']['size'] == 0 )?'':file_get_contents($_FILES['cliente_fotografia']['tmp_name']);
            //Investigar la funcion: getimageSize(), especifica ai retraemos informacion hacerca de un archivo local

            /* Sabemos que viene una superglobal con DATOS, vamos a recibir esos datos con estas variables */
            $data=[
                //Podemos usar esar superglobales pasandoles sus datos del fomularios
                'id'                        => $_POST['id'],// Al hacer POST hacemos la busquedad por el ID
                'cliente_rfc'               => $_POST['cliente_rfc'],
                'cliente_nombre'            => $_POST['cliente_nombre'],
                'cliente_direccion'         => $_POST['cliente_direccion'],
                'cliente_telefono'          => $_POST['cliente_telefono'],
                'cliente_email'             => $_POST['cliente_email'],
                'cliente_fotografia'        => $cliente_fotografia,//empty($_POST['cliente_fotografia'])?'':file_get_contents($_FILES['cliente_fotografia']['tmp_name']),//aqui vamos a trabajar y validarla de manera diferente la imagen, queremos que se guarde en la base dedatos
                /*La imagen se guarde en la base de datos para eso hacemos un uso del formulario que sea multipart (para trabajar con la superglobal FILES que trae de la PC la imagen y subirla la BD)
                    Hay que aseugrarse que haya un archivo que subir, en la parte de POST tenemos cliente_fotografia hay que asegurarse que no vaya vacio:
                    empty() si viene vacio con ? le decimos que asi se quede '' pero si no vamos a utilizar: 
                    file_get_contents() esta funcion toma un archivo fisico convertirlo en binario y subirlo a la base de datos
                    En este caso tomamos los datos que bienen en la super global $_FILES le sacamos el asociado que es lo que le pusimo al INPUT tipo file 'cliente_fotografia'
                    y le ponemos el otro asociado 'tmp_name' que es lo que vamos a buscar es el nombre del archivo fisico que seleccionamos y este biene en un subarreglo, un subasociado
                    entonces esto biene en ['tmp_name'] el nombre temporal que trae el nombre fisico del archivo
                    (CON ESTO VAMOS A SUBIR EL ARCHIVO)
                */
            ];
            
            //1° Que los campos no esten vacios
            if(empty($data['cliente_rfc']) || empty($data['cliente_nombre']) || empty($data['cliente_direccion']) || empty($data['cliente_telefono']) || empty($data['cliente_email'])){//podemos poner el arreglo $data o POST
                //Asignamos un valor en la aprte de msgError
                $data['msg_error']='Llene todos los campos';
            }
            
            #Validarr el formato de correo(email)
            if(!filter_var($data['cliente_email'],FILTER_VALIDATE_EMAIL)){
                $data['msg_error']='El formato de email no es correcto';
            }

            #Validar la no existencia de RFC o email de un lciente para que no se repita
            /* En este caso el nombre del metodo cambio de nombre y por clienteModel
            No podemos agregar un cleinte con el mismo RFC y que no se repita el correo*/
            /*if($this->clienteModel->encontrarClientePorEmailoRFC($data['cliente_email'],$data['cliente_rfc'])){
                $data['msg_error']='Email y/o RFC ya esta registrado';
            }*/// si solo modificamos el telefono solo valida del RFC o Email, esta sirve para agregar pero para modifica

            //Ya podemos validar el mensaje de error
            if(empty($data['msg_error'])){
                if($this->clienteModel->actualizar($data)){
                    redirigir('/clientes');
                }else{
                    $data['msg_error']='Error al actualizar';
                }
            }
        }else{
            //ES PARA GET
            /* Requerimos traer los datos, traemos al cliente haciendo una busquedad 
            del modelo traemos el metodo y le enviamos su parametro, en el modelo debe estar el metodo*/
            $cliente = $this->clienteModel -> editar($id);

            /* el valor que traemos ce la consulta, como nos regresa un objeto */
            $data=[
                //Podemos usar esar superglobales pasandoles sus datos del fomularios
                'id'                        => $cliente->id,// tamien nos regresa id porque en el modelo de cliente, editar nos regresa todo en SELECT
                'cliente_rfc'               => $cliente->cliente_rfc,
                'cliente_nombre'            => $cliente->cliente_nombre,
                'cliente_direccion'         => $cliente->cliente_direccion,
                'cliente_telefono'          => $cliente->cliente_telefono,
                'cliente_email'             => $cliente->cliente_email,
                'cliente_fotografia'        => $cliente->cliente_fotografia,//empty($_POST['cliente_fotografia'])?'':file_get_contents($_FILES['cliente_fotografia']['tmp_name']),//aqui vamos a trabajar y validarla de manera diferente la imagen, queremos que se guarde en la base dedatos
            
            ];
        }
        /* Vamos a enviar la vista aqui porque si en el post algo sale mal tambien se puede usar esta de aqui mismo 
            para enviarla (hay que crear la vista editar)*/
            $this->view('clientes/editar',$data);
    }
    
    /*<!-- Dar de baja a un metodo borrar que lo tenmos en index.php que se llama borrar --> */
    public function borrar($id){
        //llamamos al metodo
        $this->clienteModel->borrar($id);
        //no redirecciona a la vista de donde partio
        redirigir('/clientes');
    }

    /**
     * 
     * Reporte
     */
    public function reporte(){
        /* Usamos el modelos para sacar el arreglo y nos de la lista de cleintes*/
        $clientes = $this->clienteModel->listarClientes();
        /*listadoClientes recibe dos argumentos y nos lista pagina por pagina, vamos a generar todos de una vez
           tenemos que modificarlo o hcer un metodo doferente*/
        $this->view('clientes/reporte',$clientes);// Tenemos que crear esta vista
    }

    // Vamos a reutilizar el metodo de ListarClientes()
     /**
     * 
     * exportar csv
     */
    public function csv(){
        $clientes = $this->clienteModel->listarClientes();
        // Cambia de vista
        $this->view('clientes/csv',$clientes);
    }
    /**
     * 
     * exportar json
     */
    public function json(){
        $clientes = $this->clienteModel->listarClientes();
        // Cambia de vista
        $this->view('clientes/json',$clientes);
    }
     /**
     * 
     * exportar XML
     */
    public function xml(){
        $clientes = $this->clienteModel->listarClientes();
        // Cambia de vista
        $this->view('clientes/xml',$clientes);
    }

    /*************************************************************************************************************************************************
     * 
     * Creacion de Srvicio WEB (Parte de REST), APLICACION(el consumo seria en la publicacion de decirle como usar el servicio)
     * 
     * Con su uso con la URL con los diferentes valores de id del cliente para que nos muestre
     * los datos (puede tomar datos sin procesar o descagar en un archivo)
     * 
     */
    public function sw($id=0){// con el parametro nos aseguramos que al menos traiga un valor si no que sea 0
        $cliente = $this->clienteModel->consultaCliente($id);
        // No se requiere vista

        // Nos muestre un formato, para que la respueste este en un tipo de contenido
        header('Content-Type: application/json');

        // Se tiene que devolver el dato(lo queremos en json se usa esa funcion) vamos a codificar a JSON el arreglo
        // el parametro codifica lo que nos regres de arriba pero eso nos regresa como objeto con (->)
        // por eso forzamos a que haga el cambio con 'true' para que lo convierta a JSON
        echo json_encode($cliente,true);
    }
    /* 
     *  Se creo el Archivo Servicios.php
     */
}