<?php
include APPROOT . '/views/includes/header.inc.php';
?>
<h1>EN CONSTRUCCION</h1>
<?php include APPROOT . '/views/includes/footer.inc.php';
?>
