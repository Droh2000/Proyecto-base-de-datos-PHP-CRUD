<?php include APPROOT . '/views/includes/header.inc.php';?>
<!-- La intencion es que en el index que nos salga listado los clientes y un boton para agregar,borrer,editar, exportar 
        nececitamos una interfaz diferente
    
    Nececitamos un controlador de clientes en controller

    Vemos si esta autorizado, solicitamos una verificacion-->
<?php
    #Verificar las credenciales
    if(estaLogeado()){// ESTA LOgueado cuendo existe
        /* Aqui vamos aponer HTML, por eso cerramos */?>
        <!-- Que salgan datos de clientes -->
        <div class="row mt-3">
            <div class="col-sm-11"></div>
            <!-- Le agregamos un boton que este controlado por el modelo MVC en el href  -->
            <div class="col-sm-1"><a class="btn btn-primary" href="<?= URLROOT ?>/clientes/agregar"><i class='fa fa-plus'></i></a></div>
        </div>
        <hr>
        <!-- Creacion de  una table -->
        <table class="table table-striped">
            <thead>
                <!-- Cosas que salgan en el encabezado -->
                <tr>
                    <th>ID</th>
                    <th>RFC</th>
                    <th>Nombre</th>
                    <th>Direccion</th>
                    <th>Correo</th>
                    <th>Telefono</th>
                    <th>Fotografia</th>
                    <th>Opciones</th>
                </tr>
            </thead>
            <tbody id="cientes">
                <!-- Se espera recibir de consulta los registros de la table cleintes
                Vamos a recorrerlo como arreglo en un foreach, vamos a trabajr con PHP vamos a trbajar con el modelo que no regresas estos datos atravez del controlador-->
                <?php foreach($data['clientes'] as $registro){ ?><!-- Es el regreso de la consulta,  $data['clientes'] porque en la vista estamos recibeindo los valores en la vairable $data asociado en clientes-->
                    <!-- Le pusmimos $registro que son las variables que vamos a manejar -->
                    <tr>
                        <!-- Empezariamos a crear renglones con esos registros (con la variable)  
                        La consulta de la base de datos nos envia una conulta tipo OBJETO por eso usamos el apuntado '->'
                        e imprimimos el valor que nececitemos-->
                        <td scope="row"><?= $registro->id ?></td>
                        <td><?= $registro->cliente_rfc ?></td>
                        <td><?= $registro->cliente_nombre ?></td>
                        <td><?= $registro->cliente_direccion ?></td>
                        <td><?= $registro->cliente_email ?></td>
                        <td><?= $registro->cliente_telefono ?></td>
                        <!-- En este caso con src='' viene de todo un proceso con la BD por lo tanto usamos que la fuente es de memoria
                            la tomamos de una variable (la imagen se subio a jpg)y lo convertimos a PNG (es lo mas comun) y luego se convierte en base64
                            con PHP lo convertimos a base64_encode (vamos a codificar lo caracteres raros que estan por defecto) convierte todos esos caracteres para que sean legibles --> <!-- Se le agrego para que donde no haya fotografia slga la palabra fotogradi y controlar el tamaño -->
                        <td><img src="data:image/png;base64,<?= base64_encode($registro->cliente_fotografia)?>" alt="Fotografia" width="30"></td><!-- Este recibira un tratamiento especial, Trabajaremos como mostrar una imagen -->
                        <!-- (Parte de Editar y Borrar):
                            Hacer que se vean como boton al acncla le agregamos su clase,
                            A esta ancla en el href que nos lleve a un controlador (metodo) y que decirle que registro sera el afectado para editar
                            Queremos que nos regrese la URLROOT y nos lleve hasta el metodo y a este metodo nececitamos enviarle el ID (esto nos recibe por GET) con este registro hacemos la consulta
                            Se le agrego btn-sm para que esten mas pqueños los botones-->
                        <td><a class="btn btn-warning btn-sm" href="<?= URLROOT ?>/clientes/editar/<?= $registro->id ?>"><i class="fa fa-edit"></i></a>
                            <a class="btn btn-danger btn-sm" href="<?= URLROOT ?>/clientes/borrar/<?= $registro->id ?>"><i class="fa fa-trash"></i></a></td><!-- Es la parte de las opciones -->
                    </tr>
                <?php } ?>
            </tbody>
        </table>

        <!-- Aqui vamos aponer la navegacion de la paginacion (Del metodo index de Clientes.php de controllers) con bootstrap-->
        <nav aria-label="Page navigation">
            <!-- Aqui hay que combinar PHP -->
            <div class="row"><!-- Esta es la parte de la flecha << -->
                <!-- Son parafos para poner el limite de registros 
                    Trabajamos un asociado dentro de $data (Que es lo que estamos recibiendo en la vista) que se llame segun lo que nececitemos entonces lo usamos como un arreglo asociado
                    Estos se deberion haber creado en el modelo Cliente.php 
                Vamos a mostrar el Limite segun lo que tenga del numero de registro que falten por recorrer-->
                <div class="col-sm-6"><p>Mostrando <?= $data['limite'] ?> de <?= $data['registros'] ?> clientes registrados</p></div>
                <!-- Para poner que pagina actual esta y y de cuantas paginas en total -->
                <div class="col-sm-6"><p>Pagina <?= $data['pagina'] ?> de <?= $data['paginas'] ?></p></div><!-- Estas varaibles estan creadas en el modelo Cliente.php -->
            </div>
            <!-- Esta lista que esta modificada para que se vea horizontal queremos que ese disable depende si hay paginas hacia atras o no -->
          <ul class="pagination justify-content-center"> <!-- (Esta parte es la de las flechas previa) -->
              <!-- Modificamos con PHP, vamos a preguntar si la variable data que estamos recibiendo preguntas con ternario
                   ya que con page-item disabled la tenemos desabilitada pero no para siempre 
                Con PHP vamos a preguntar si del areglo data que recivimos si el numero de pagina es menor o igual 1 si es verdad (lo desactivamos) si no, no haga nada-->
            <li class="page-item<?=($data['pagina']<=1)?'disabled':''?>"><!-- Esta es la parte de la flecha >> -->
                <!-- En caso que no este desabilitado manejamos el ancla aqui abajo 
                    Si la pagina es <=1 no queremos que vaya a ningun lado por eso el #, pero si esta habilitado:
                    debemos de enviarlo a una ruta, ponemos URLROOT y le concatenamos al controlador/metodo clientes/index y que nos envie
                        el limite que esta en el arreglo data (por eso lo creamos en la parte de paginacion) y luego le concatenamos
                        depues de '/' la pagina. Con el fin de representar la URL de navegacion-->
              <a class="page-link" href="<?=($data['pag_previa']<=1)?'#': URLROOT.'/clientes/index/'.$data['limite'].'/'.$data['pagina']?>" aria-label="Previous">
                <span aria-hidden="true">&laquo;</span>

              </a>
            </li>
            <!-- Cambiamos esta seccion para usar un ciclo desde el 1 hasta el total de la spaginas para hecer ese despliegue de las paginas
                en el total de la divicion de los registros y el limite
            solo trabajamos con un un li (esto se despliega tantas paginas tenga), Abrimos ciclo -->
            <?php for($i=1;$i<=$data['paginas'];$i++){ //Los elementos con $data['paginas'] hacemos referencia al total de paginas?>
            <!-- Ponemos el active dependiendo el valor de la pagina comparada con la desplegada en el ciclo, la reseltamos, y en href = ponemos la ruta y ponemos en que pagina estamos 
                Estamos difernciando la pagina en la que estamos con un color-->    
            <li class="page-item <?=($data['pagina']==$i)?'active':''?>"><a class="page-link" href="<?= URLROOT.'/clientes/index/'.$data['limite'].'/'.$i ?>"><?= $i ?></a></li>
            
            <?php }?><!-- Con lo anterios todos los numeros del total de paginas para la navegacion -->
            <li class="page-item <?=($data['pagina']>=$data['paginas'])?'disabled':''?>"> <!-- En este caso sera cual es el maximo limite (seri paginas) si la pagina es mayor o igual al total de paginas desabilita porque ya no puede avanzar  -->
              <a class="page-link" href="<?=($data['pagina']>=$data['paginas'])?'#': URLROOT.'/clientes/index/'.$data['limite'].'/'.$data['pag_siguiente']?>" aria-label="Next">
                <span aria-hidden="true">&raquo;</span>
                <span class="visually-hidden">Next</span>
              </a><!-- (Y con lo anterior puede avanzar con las flechas) Toda bia nos hace falta usar paginas para que en la parte azul salgan las paginas -->
            </li>
          </ul>
        </nav>
        
    <?php }else{ ?>
        <div class="alert alert-inf">
            Usted no esta Autorizado
        </div>    
<?php
    }
?>

<?php include APPROOT . '/views/includes/footer.inc.php';?>