<?php
#header('Content-type: application/json'); // En la vita recibimos el arreglo de $data['clientes']
#header('Content-Disposition: attachment; filename=clientes.json');

// Primera Fomra de Hacerlo
/*
    Uso de la Funcion: json_encode() nos convierte un arreglo en JSON
    json_encode() un objeto JSON nos lo convierte a un arreglo
*/
#echo json_encode($data['clientes']);
/*
    En un Inicio tenemos un problema que nos sale vacio el archivo
    Si hacemos debug con el $data['clientes'] arriba de los headears
    Vemos que tenemos los simbolos de la imagen (no son interpredaso por ASCII) salen muchos espacio en blanco
    Una solucion es que la fotografia no se migre (No lo puede interpretar), la otra es que desde la consunlta de la BD

*/
/*
    Comentamos todo lo de arriba para hacer que se garde solo y nosmuestre solo un mensaje de guardado
    se le agrego el encabesado y se usao la misma funcion de csv
    Se le pondra para saber cuando lo hizo lo de guardar el archivo
*/
# Segunda Forma de Hacerlo
?>
<?php include APPROOT . '/views/includes/header.inc.php'; ?>

<?php file_put_contents(APPROOT.'/files/clientes_'.time().'.json',json_encode($data['clientes']));?>

<div class="alert alert-info">
    Archivo Generado
</div>

<?php include APPROOT . '/views/includes/footer.inc.php'; ?>