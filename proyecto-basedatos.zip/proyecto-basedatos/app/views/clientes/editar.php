<?php include APPROOT . '/views/includes/header.inc.php'; ?>
<!-- Formulario de Editar -->
<div class="row mt-3">
    <div class="col-sm-3"></div>
    <div class="col-sm-6">
        <div class="row">
            <div class="col-sm-11"><h4 >  Registrar </h4></div>
            <div class="col-sm-1"><i class="fa fa-user text-info"></i></div>
        </div>
        <hr>
        <!-- despliegue de mensajes de error -->
        <div class="alert alert-warning 
            <?= (isset($data['msg_error']) && !(empty($data['msg_error'])))?'d-block':'d-none'; ?>"> 
            <?= (isset($data['msg_error']) && !(empty($data['msg_error'])))?$data['msg_error']:''; ?>
       </div>
       <!-- Ponerle que sea del metodo editar y hay que mandarle el argumento del metodo editar del controlador para POST no lo recive pero asi lo preparamos el metodo
       por POST solo recibe los datos del formulario

        En el metodo del controlador se le envia un dato, aseguramos que exista ese dato en la vista con isset($data['id']) si existe  madame el valor-->
       <form action="<?= URLROOT ?>/clientes/editar/<?=isset($data['id'])?$data['id']:0?>" method="POST" enctype="multipart/form-data">
       <!--El ID no se puede recibir por POST en la ulrl, hay que asegurarse que se envie el ID par ahecerse la busquedad para el metodo actualizar, al hacer post, agregamos el ID a este formulario pero oculto
         para tener el asociado id en POST para asignarlo a CLientes.php en el metodo editar y usarlo en la parte de la busquedad
        tenemos en data todos los argumentos, de ahi podemos mostrar los valores que traemos en cada-->
        <input type="hidden" name='id' value="<?=isset($data['id'])?$data['id']:0?>">
        <div class="row">
            <div class="col-sm-4">
                <div class="form-group">
                    <label for="cliente_rfc" class="form-label">R.F.C.</label>
                    <input type="text" class="form-control" name="cliente_rfc" id="cliente_rfc" aria-describedby="helpId" placeholder="R.F.C." value="<?=isset($data['cliente_rfc'])?$data['cliente_rfc']:''?>"><!-- Se le agrego a todos los campos del formulario la instruccion de values = para saber que valor traemos y que nos este vacio -->
                </div>
            </div>
            <div class="col-sm-8">
                <div class="form-group">
                    <label for="cliente_nombre" class="form-label">Nombre de Cliente</label>
                    <input type="text" class="form-control" name="cliente_nombre" id="cliente_nombre" aria-describedby="helpId" placeholder="Nombre de Cliente" value="<?=isset($data['cliente_nombre'])?$data['cliente_nombre']:''?>">
                </div>
            </div>
        </div>
            <div class="row">
                <div class="col-sm-12">
                    <div class="form-group">
                        <label for="cliente_direccion" class="form-label">Dirección</label>
                        <input type="text" class="form-control" name="cliente_direccion" id="cliente_direccion" placeholder="Dirección" value="<?=isset($data['cliente_direccion'])?$data['cliente_direccion']:''?>">
                    </div> 
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4">
                    <div class="form-group">
                        <label for="cliente_telefono" class="form-label">Teléfono</label>
                        <input type="text" class="form-control" name="cliente_telefono" id="cliente_telefono" placeholder="Teléfono" value="<?=isset($data['cliente_telefono'])?$data['cliente_telefono']:''?>">
                    </div>
                </div>
                <div class="col-sm-8">
                    <div class="form-group">
                      <label for="cliente_email" class="form-label">Email de Cliente</label>
                      <input type="text" class="form-control" name="cliente_email" id="cliente_email" aria-describedby="helpId" placeholder="Email de Usuario" value="<?=isset($data['cliente_email'])?$data['cliente_email']:''?>">
                    </div>
                </div>
            </div>
            <div class="row">
              <div class="col-sm-8">
                <label   for="cliente_fotografia">Fotografía</label>
                <input type="file" class="form-control" id="cliente_fotografia" name ="cliente_fotografia"><!-- no se puede traer la parte fisica del nombre del archivose va a hacer mucho rollo    -->
              </div>
              <div class="col-sm-4"></div>
          </div>
 
            <div class="row mt-3">
               
                <div class="col-sm-4"></div>
                <div class="col-sm-4">
                    <button type="submit" class="btn btn-success btn-block">Actualizar</button>
                </div>
                <div class="col-sm-3"></div>
            </div>
            
        </form>
    </div>
    <div class="col-sm-4"></div>
</div>
<?php include APPROOT . '/views/includes/footer.inc.php'; ?>