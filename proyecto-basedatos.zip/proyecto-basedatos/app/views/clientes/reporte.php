<!-- no vamos a poner encabezados porque vamos a generar un archivo 
    Que nos genere un pdf
-->
<?php
/**
 * Uso de DomPdf, Ejemplo Simple
 */

 # Construir la tabla de Clientes que es lo queremos imprimr, Copiamos y pegamos todo el codigo de la tabla de clientes
 /*
   Aqui recibimos 'clientes' en la variable llamada $data
   la tabla usa reglas CSS, para incluirlas con la etiqueta <head>Link</head> se lo argegamos dentro de la variable $html
   No Todas las reglas se va a poder enderizar asi 

   A partir del tbody, estamos usando PHP pero Aqui abrimos php desde arriba y $html es una varaible cadena que
   Por lo tanto donde empeza <?php cerramos la cadena y concatenamos con '.' lo que sigue (se elimina todos los <?php y ?>)
   
   Para asiganr la dema cadena usamos el operador especial, .= con la variable $html que es como '+=' en este caso concatenado
    */ 
    //$html = 'Hola';
 /* Hablamos de una espacio de nombre donde hay un conjunto de clases
     Para eso usamos el comando 'use'
     y este ahorro de la direccion (A que todo lo necesario lo vamos a encontrar en
     ese espacio de nombre 'Dompdf')

     Para crear un espacio de nombre se usa namespace directorio, esto antes de class es decir si queremos poner en una namesapace entes del nombre de la clase y poner la ruta \direcotrio
     eso hace que podamos usar en Dompdf el 'use' (Es como Import los paquetes) 
*/
$html = '<head><link rel="stylesheet" href="'. URLROOT .'/css/bootstrap.min.css"></head>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>RFC</th>
                    <th>Nombre</th>
                    <th>Direccion</th>
                    <th>Correo</th>
                    <th>Telefono</th>
                    <th>Fotografia</th>
                    <th>Opciones</th>
                </tr>
            </thead>
            <tbody id="cientes">'; //Finaliza la cadena pero hay que seguir concatenando
            foreach($data['clientes'] as $registro){ 
                $html.='<tr>
                    <td scope="row">'. $registro->id .'</td>
                    <td>'. $registro->cliente_rfc .'</td>
                    <td>'. $registro->cliente_nombre .'</td>
                    <td>'. $registro->cliente_direccion .'</td>
                    <td>'. $registro->cliente_email .'</td>
                    <td>'. $registro->cliente_telefono .'</td>
                    <td><img src="data:image/png;base64,'. base64_encode($registro->cliente_fotografia) .'" alt="Fotografia" width="30"></td>
                </tr>';
            }
            $html.=' </tbody></table>';

use Dompdf\Dompdf;
# se crea una instancia de todas las clases que conforman Dompdf
$pdf = new Dompdf();
/* Lo mas simple para un ejemplo es usando sus metodos
El usado afuerzas es, Convierte HTML a PDF */
# Preparacion
$pdf->loadHtml($html);
/* En esste caso son muchos datos, queremos cambiar la posicion de la hoja */
#Configuracion de la presentacion
$pdf->setPaper('legal','landscape');
/* Reconstruye o renderiza, lo transforma */
# Conversion de html a pdf
$pdf->render();
/* Para presentarlo podria ser, echo $pdf->output() (esta es la salida) */    
//echo $pdf->output();
# Salida
/* queremos que nos genera un Scrip */
$pdf->stream('clientes.pdf');

/* Sacar un archivo en otro fromato con uno comandos para crear un arhivo de texto plano
y nos lo abrecon la aplicacion que lo nececite segun el formato como JSON, CSV 

    La funcion:
            fopen('se le da la direccion con el nombre y extencion',El tipo);
            tiene un lista de modos posibles (El tipo)
    
    Como la imagen la tomamos con file_get_contents (LEER) tambien tneemos 
    file_put_contents (PONER) el contenido de un archivo en un espacio fisico
    Verificar de todos modos: en fopen(),fwrite(),fclose()
*/