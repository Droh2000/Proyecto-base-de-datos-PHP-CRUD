<?php include APPROOT . '/views/includes/header.inc.php'; ?>
<?php
/**
 * 
 * Exportar  XML
 * 
 */

/*
    uso de las funciones
    Para estas funciones nececitamos un manejadro (handler)
    que sera xml
    al final le ponemos el modo (Solo lectura, Escritutra)
*/
# Creacion de Archivo con fopen()
//Nececitmaos uns ruta y un nombre de Archivo con identificador (time()) con extencion .xml, en senguida el MODO (Solo lectura(r),Lecctura y escritura y el puntero es pone al inicio del archivo(r+),Solo escritura (w) y (w+),a,a+)
$xml = fopen(APPROOT.'/files/clientes_'.time().'.xml','w+');// el uso de w+ nos va a crear el archivo, escribe en el y si ya existe, utiliza el archivo lo borra y escribe (pero igual no sucedera por la funcion time())
//Se nececita este fwrite para asegurar el encabezado asi que le ponemos la variave para decir que vamos a escribir en esa variable el encabezado XML
fwrite($xml,'<?xml version="1.0" encoding="UTF-8" ?>');//Para identifcar el XML con un encabezado
/* Ahora le decimos que nos ponga un salto de linea y ponemos la esctructura general (clientes) 
    y otro salto de linea*/
fwrite($xml,"\n<clientes>\n"); 
foreach($data['clientes'] as $registro){ 
    /* en lugar del echo ponemos el fwrite siempre poiendo en donde vamos a escribir ($xml)
        Luego ponemos el identificadro de registro (cliente)
        luego el identificador de valor (id) y le concatemos su valor y despues cerramos la etiqueta*/
    fwrite($xml,"<cliente>\n<id>". $registro->id ."</id>\n<rfc>". 
    $registro->cliente_rfc. "</rfc>\n<nombre>".
    $registro->cliente_nombre ."</nombre>\n<direccion>".
    $registro->cliente_direccion ."</direccion>\n<telefono>".
    $registro->cliente_email ."</telefono>\n<correo>".
    $registro->cliente_telefono ."</correo>\n<fotografia>".
    $registro->cliente_fotografia."</fotografia>\n</cliente>\n");// como ya viene convertido ya no se necita convertir aqui a base64
}
fwrite($xml,"</clientes>");// el cierre de la esctructura general 
// Cerramos el puntero
fclose($xml);
//y PHP par poder meter la parte de footer?>
<div class="alert alert-info">
    Archivo Generado
</div>
<?php include APPROOT . '/views/includes/footer.inc.php'; ?>