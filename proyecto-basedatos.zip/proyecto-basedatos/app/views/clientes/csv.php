<?php
/**
 * 
 * Exportar  CSV
 * 
 */

 /* Tenemos la carpeta file para guardar archivos en fisicos pero ahora 
    con el estilo presentacion PDF
    Al usar fopen(hay que guardar el tipo de extencion del archivo) 
    pero podemos ayudar en este caso el header de redirigir de hepers nos sirve para poner la extencion del archivo*/
// sus argumntos ponemos el tipo de contenido y el tipo de archivo    
    header('Content-type: application/csv'); // detecta el tipo de dato
 // Tambien podemos sugerir el nombre del archivo
    header('Content-Disposition: attachment; filename=clientes.csv');   // esto hace que se abra el cuadro de dialogo (es como es Steam de DomPDF) cuando nos pregunte que sea guardar o abrir el archivo
/* Le decimo que nos guarde el encabezado del archivo, (lo que nos regresa del arrchivo CSV) los encabezados (con la fotografia nos enviaria el codigo base64 (NO RECOMENDABLE ENVIAR IMAGENES EN BASE64) ) */
echo $csv = 'ID, R.F.C, NOMBRE, DIRECCION, TELEFONO, CORREO, FOTOGRAFIA'."\n"; # Hay que ponerle salto de linea (Esto va a ir a texto plano) le concatenamos la secuencia de escape
// Nececitamos los Datos (ya que en la llamada estamos recibiendo  todos los clintes)
// Hay una situacion que en cliente_direccion hay comas y eso hara que se separa en varios campos asi que se pone ente "" 
foreach($data['clientes'] as $registro){ 
    //Aqui en lugar de $html.='<tr> se pone el echo en lugar de td se le pone una ','
    echo $csv .= $registro->id .','. $registro->cliente_rfc 
    .','. $registro->cliente_nombre .',"'. $registro->cliente_direccion .'",'. $registro->cliente_email .','
    . $registro->cliente_telefono .','. base64_encode($registro->cliente_fotografia)."\n";
}// con esto ya se tiene cada linea de recorridos a foreach

/*
    con echo $csv, no importa que tengamos el echo atras de la variable ya ese es para el header (el encabezado) queremos que lo muestre y guarde
    Lo podemos quitar y con dar click nos guarda automaticamente el archivo
    Asi como le quitamo los dos header para que no sala la ventana y se guarde directamente en la carpeta files
    y tambien se comentan los echo

    si le damos click nos envia a la vista pero no muestra nada
*/

// fopen(),fwrite(),fclose(): Leer sobre esto .......................
// Pendiente el uso de file_put_contents() el uso de esta funcion sustituye el uso de las funciones de arriba
/*
    Vamos a madar este por archivo por defecto a la carpeta files del proyecto
    Usamos la funcion file_put_contents() por parametros le pasamos el nombre del archivo y su ruta
    despues de APPROOT.'/files/' le decimos que guarde un archivo llamado clientes y como sugerencia
    (AGREGARLE UN IDENTIFICADOR)  para que no se remplaze, AGREGARLE LA FECHA Y HORA con la funcion
    time() que nos la regresa la fecha/hora en formato UNIX (que es un numero que identifica ese momento) (ASI SE DIFERENCIAN LOS ARCHIVOS)
    Despues le ponemos la extnecion
    Le indicamos cual archivo (Que es lo que nos va a poner de salida) para eso pusimos en una varaible todo el contenido de arriba

    Asi se hace la exportacion a CSV
*/
file_put_contents(APPROOT.'/files/clientes_'.time().'.csv',$csv);

