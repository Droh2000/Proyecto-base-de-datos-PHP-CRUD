<?php include APPROOT . '/views/includes/header.inc.php';?>
<!-- Formulario de Login -->
<div class="row mt-3">
<div class="col-sm-4"></div>
<div class="col-sm-4">
    <div class="row">
      <div class="col-sm-11"><h4>Login</h4></div>
      <div class="col-sm-1"><i class="fa fa-key text-warning"></i></div>
    </div>
    <hr>
  <!-- Desplegue de los mensajes de error-->
    <div class="alert alert-warning <?= (isset($data['msg_error'])&&!(empty($data['msg_error'])))?'d.block':'d-none'; ?>">
    <?= (isset($data['msg_error'])&&!(empty($data['msg_error'])))?$data['msg_error']:''; ?>
      <!-- Debe ser que si hay un valor en la variable, msg-erro que se vea este parte y si no que no se vea -->
      <!-- con la ayuda de la clase d-none (d.blck) para que no se vea o
          paraeso usamos una condicion de PHP, /////////////////////////////////////////////////////-->
    </div>
    <!-- En el action mande a llamar a la URl que esta en, tenemos en el header.inc tnemos una llamada
    a este misma archivo login.php pero con el metodo GET, aqui en el form usamos la misma llamada pero ahora con POST
    Se debe tener asi por algo, tenemos dos llamada una con GET y esta con POST
    Esto nos conviene en que cuando sea por GET nos presente el formulraio y cuando se post hacemos una validacion,tomamos los datos del fomulario y buscamos en una tabla-->
    <form action="<?=URLROOT?>/usuarios/login" method="POST">
    <!-- Que pedimos: para ingresar -->
        <div class="form-group">
          <label for="usuario_uid" class="form-label">ID de Usuario</label>
          <!-- Paara poner un nombre, de preferecnia se usa el mismo de la base de datos --> 
          <input type="text" class="form-control" name="usuario_uid" id="usuario_uid" aria-describedby="helpId" placeholder="ID de Usuario">
        </div>
        <div class="form-group">
          <label for="usuario_password" class="form-label">Password</label>
          <input type="password" class="form-control" name="usuario_password" id="usuario_password" placeholder="Password">
        </div><br>
        <button type="submit" class="btn btn-success">Login</button>
    </form>
</div>
<div class="col-sm-3"></div>
</div>
<?php include APPROOT . '/views/includes/footer.inc.php';?>