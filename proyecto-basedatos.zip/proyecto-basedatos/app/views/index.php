<?php
/* Este nos carga la vista incial, Todas las vistas van a tener cosas fijas
con encabezado, pied de pagina y el contenido, pero el contenido cambia (ES VARIABLE), las otras dos son fijas 
La recomendacion es crear el encavezado y pie de pagina y despues se le agrege el contenido
se creo la carpeta includes en que esta estos dos que despues se incluiran en este archivo index php

Vamos a tener dos situaciones en la automatizacion,en la que para acceder a la URL, tenemos la parte publica y prvivada
enla public es con con URL Rute y la privada se creara una variabe Approute es cuando se nececite que ir a esta parte privada

nos vamos a congif.inc.php en includes y creamos esas constantes


Aqui incluimos el footer y header
Donde esta el archivo que vamos a incluir:
le decimos que vaya a la ruta de la aplicacion y concatenamos la carpeta
view de include e incluimos los archivos
*/
include APPROOT . '/views/includes/header.inc.php';
?>
<p>Inicio</p>
<?php include APPROOT . '/views/includes/footer.inc.php';
?>

<!--
    Para mandar a llamar a este index que tenemos aqui es desde la carpeta librarie en Ruta.php
    Ahi tenemos un controlador Home y dentro de este mande a llamar al metodo index
    entonces vamos a tener que construir el controlador home en controllers Home.php
-->