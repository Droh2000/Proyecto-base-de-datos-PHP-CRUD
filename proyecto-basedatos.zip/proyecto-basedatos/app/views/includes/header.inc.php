<!doctype html>
<!-- Le agregamos la clase h-100 lo que es el heigh que sea al 100%-->
<html class="h-100" lang="en">
  <head>
      <!-- Se puso en el titulo  eso de PHP para que imprima el titulo de config.inc.php de la carpeta includes, le pusimos TITLE-->
    <title><?= TITLE ?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS v5.0.2, a las rutas se le agrego URLROOT porque estan en la parte publica, como es de PHP hay que meterla
        dentro de sus etiquetasl le ponemos < ?= porque seria lo mismo que < ?php echo  -->
    <link rel="stylesheet" href="<?= URLROOT ?>/css/bootstrap.min.css"><!-- con este URLROOT toma la direccion desde c://.... -->
    <link rel="stylesheet" href="<?= URLROOT ?>/css/all.min.css"><!--Cargamos  todos los tipos de FONT Awesome-->

  </head>
  <body>
    <div class="container">
        <header class="mt-2"><!-- Le ponemos clase para despues ponerle un margen en bootstrap-->
            <h1>Empresas Tecnologicas, S.A de C.V</h1>
        </header>
        <nav class="navbar navbar-expand-md navbar-light bg-light">
              <div class="container">
                
                <a class="navbar-brand" href="#"><i class="fa-brands fa-apple text-info"> </i></a><!-- Con <i> usamos como para funetes de fontAwesome usando una clase y vemos los parametro que podemos usar para cada una de las imagenes que podemos poner, En caso pusimos el simbolo de apple-->
                    
                <button class="navbar-toggler d-lg-none" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavId" aria-controls="collapsibleNavId"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="collapsibleNavId">
                    <ul class="navbar-nav me-auto mt-2 mt-lg-0">
                        <li class="nav-item active">
                            <!-- Esto significa que va atener un comportamiento diferente, con (CURRENT) solo se vera en situaciones especiales-->

                            <!-- Ponemos ese echo de PHP nos lleve a URLROOT al incio, con ese y con la / le especificamos, 
                                lo de <span class='visually-hidden'>(current)</span> (lo eliminamos) es para tableta de lectura de libros cuando no acepta una situacion grafica -->
                            <a class="nav-link" href="<?= URLROOT ?>/">Inicio</a>
                        </li>
                        <li class="nav-item">
                            <!-- Se tendria que hacer un MVC para cada link, Le ponemos que nos lleve al controlador clientes no hay problma si no le ponemos la otra / que seria el metodo porque sta definido como index que es el por defecto-->
                            <a class="nav-link" href="<?= URLROOT ?>/clientes">Clientes</a><!-- Para eso creamos la tabla clientes -->
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="dropdownId" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Reportes</a>
                            <div class="dropdown-menu" aria-labelledby="dropdownId">
                                <a class="dropdown-item" href="<?= URLROOT ?>/clientes/reporte">Clientes</a><!-- aqui si le ponemos el metodo reportes -->
                                <a class="dropdown-item" href="#">Ventas</a>
                            </div>
                        </li>
                        <!-- Seccion de Exportacion a otro tipo de archivo -->
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="dropdownId" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Exportar</a>
                            <div class="dropdown-menu" aria-labelledby="dropdownId">
                                <a class="dropdown-item" href="<?= URLROOT ?>/clientes/csv">Clientes a CSV</a><!-- aqui si le ponemos el metodo reportes -->
                                <a class="dropdown-item" href="<?= URLROOT ?>/clientes/json">Clientes a JSON</a>
                                <a class="dropdown-item" href="<?= URLROOT ?>/clientes/xml">Clientes a XML</a>
                            </div>
                        </li>
                    </ul>
                    <!-- Se borro el formulario para agregar la seccion del logion y logout -->
                    <ul class='navbar-nav d-flex my-2 my-lg-0'>
                        <!-- Agregaso despues de verificar que ingreso al sistema
                        En el helpers tenemos la funcion estalogueado, vamos a preguntar -->
                        <?php if(estaLogeado()){ ?>
                            <!--Muestre el nombre y Logout
                                Vamos a poner codigo HTML por eso el cierre del PHP-->
                            <li class="nav-item">
                                <!-- Para mostrar en la pantalla el nombre del Usuario, de la superglobal SESSSION -->
                                <a class='nav-link active' href="#"><?= $_SESSION['usuario_nombre']?></a>
                            </li>
                            <li class="nav-item">
                                <a class='nav-link active' href="<?= URLROOT ?>/usuarios/logout">Salir</a>
                            </li>
                        <!-- Vuelve a abrir y cerrar codigo PHP -->    
                        <?php } else{ ?>
                            <!--/Muestro lo mismo que esta -->
                        
                        <li class="nav-item">
                            <!-- Para acceder a la ruta va a ser que tiene que ve conlo publico por eso se usa URLROOT y se le concatena
                                un controlador que existe llamasa usuarios y que cargue el metodo logion -->
                            <a class='nav-link active' href="<?= URLROOT ?>/usuarios/login">Login</a>
                        </li>
                        <li class="nav-item">
                            <a class='nav-link active' href="<?= URLROOT ?>/usuarios/register">Registrar</a>
                        </li>
                        <!-- cierra la llave del codigo PHP -->
                        <?php } ?>
                    </ul>
                </div>
          </div>
        </nav>
        <!-- Pdriamos poner este o section-->
        <main class="container">
