</main>
        
        <footer>
            Pie de paginas
        </footer>
    </div>

    <!-- Bootstrap JavaScript Libraries -->
    <script src="<?= URLROOT ?>/js/bootstrap.min.js"></script>
    <!--  Se agrego otra libreria: Para que nos funcione todo -->
    <script src="<?= URLROOT ?>/js/jquery-3.6.0.min.js"></script>
  </body>
</html>