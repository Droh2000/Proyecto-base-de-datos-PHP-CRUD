<?php


//Fucnion regdirigir
session_start();//Crear o utilizar una sesion y solose hace un sola vez, que es cuando se carge en auto_load.php se carga la sesion

function redirigir($location){
    /*(no cargaremos la vista directamente) 
    Lo que vamos a hacer es una llamada a un controlador/metodo
    vamos hacerlo una vista de manera controlada*/
    //Esta funcion nos permit abrir cualquier documento o mandar de cualquier tipo
    /* lleva esta cadena como argumento, nos interesa que vala a la parte publica URLROOT y la location de la pagina que le enviemos */
    header('Location: '.URLROOT.$location);
}

// Si esta creada la sesion
function estaLogeado(){
    //Para hacerlo de forma global, si el asociado de la superglobal esta creado quiere decir que ya paso por el proceso de validacion
    // y se creo esta sesion
    return (isset($_SESSION['usuario_id']))?true:false;
}